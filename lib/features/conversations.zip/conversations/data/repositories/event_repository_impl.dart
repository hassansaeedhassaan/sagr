import 'package:dio/dio.dart';
import 'package:sagr/core/error/exceptions.dart';
import 'package:sagr/core/error/failures.dart';
import 'package:dartz/dartz.dart';
import 'package:sagr/features/conversations/data/models/message_model.dart';
import '../../domain/repositories/event_repository.dart';
import '../datasource/conversations_data_source.dart';
import '../models/conversation_model.dart';
import '../models/event_model.dart';

class ConversationsRepositoryImpl implements ConversationRepository {
  
  final ConversationsDataSource conversationsDataSource;
  
  ConversationsRepositoryImpl(this.conversationsDataSource);

  @override
  Future<Either<Failure, List<ConversationModel>>> getConversations(filter) async {
    try {
      final productsData = await conversationsDataSource.getConversations(filter);
      return Right(productsData);
    } on ServerException {
      return Left(ServerFailure());
    }
  }
  
  @override
  Future<Either<Failure, EventModel>> getEventDetails(int id) async{
    try {
      final productsData = await conversationsDataSource.getEventDetails(id);
      return Right(productsData);
    } on ServerException {
      return Left(ServerFailure());
    }
  }


    @override
  Future<Either<Failure, List<MessageModel>>> getMessages(int id, filter) async{
    try {
      final productsData = await conversationsDataSource.getMessages(id, filter);
      return Right(productsData);
    } on ServerException {
      return Left(ServerFailure());
    }
  }

  @override
  Future<Either<Failure, Response>> apply(Map<String, dynamic> body) async {
     try {
      final eventData = await conversationsDataSource.apply(body);
      return Right(eventData);
    } on ServerException {
      return Left(ServerFailure());
    }
  }


  @override
  Future<Either<Failure, Response>> sendMessage(Map<String, dynamic> body) async {
     try {
      final eventData = await conversationsDataSource.sendMessage(body);
      return Right(eventData);
    } on ServerException {
      return Left(ServerFailure());
    }
  }



}
 