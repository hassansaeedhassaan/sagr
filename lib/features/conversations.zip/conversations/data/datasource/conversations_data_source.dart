import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:dio/dio.dart' as dioHttp;
import 'package:sagr/features/conversations/data/models/message_model.dart';
import '../../../../core/error/exceptions.dart';
import '../../../../models/pagination_filter.dart';
import '../models/conversation_model.dart';
import '../models/event_model.dart';
import 'package:http_parser/http_parser.dart';

import 'package:dio/src/form_data.dart' as formData;

abstract class ConversationsDataSource {
  Future<List<ConversationModel>> getConversations(PaginationFilter filter);

  Future<EventModel> getEventDetails(int id);
  Future<List<MessageModel>> getMessages(int id, PaginationFilter filter);
  Future<Response> apply(Map<String, dynamic> body);

  Future<Response> sendMessage(Map<String, dynamic> body);
}

class ConversationsDataSourceImpl extends ConversationsDataSource {
  final Dio dio;

  ConversationsDataSourceImpl({required this.dio});

  @override
  Future<List<ConversationModel>> getConversations(filter) async {
    var response = await dio.get(
        'https://sagr.libraryrajab.com/api/v1/conversations',
        queryParameters: {
          'page': filter.page,
          'limit': filter.limit,
          'eventType': filter.eventType ?? 'all',
          'ed': filter.eventDuration // event duration is event finished or not.
        });

    if (response.statusCode == 200) {
      
      final List<ConversationModel> conversations = response.data['data']
          .map<ConversationModel>((data) => ConversationModel.fromJson(data))
          .toList();

      return conversations;

    } else {
      throw ServerException();
    }
  }

  @override
  Future<EventModel> getEventDetails(int id) async {
    var response = await dio.get(
        "https://sagr.libraryrajab.com/api/v1/events/${id}/show");

    if (response.statusCode == 200) {
      final EventModel event = EventModel.fromJson(response.data['data']);

      return event;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<List<MessageModel>> getMessages(id, filter) async {
    var response = await dio.get(
        'https://sagr.libraryrajab.com/api/v1/conversations/$id/messages',
        queryParameters: {
          'page': filter.page,
          'limit': filter.limit,
          'eventType': filter.eventType ?? 'all',
          'ed': filter.eventDuration // event duration is event finished or not.
        });

    if (response.statusCode == 200) {
// print(response.data['messages']['data'][0]['user']);
      final List<MessageModel> messages = response.data['messages']['data']
          .map<MessageModel>((data) => MessageModel.fromJson(data))
          .toList();

      return messages;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Response> apply(Map<String, dynamic> body) async {
    try {
      final response = await dio.post(
          "https://sagr.libraryrajab.com/api/v1/event/apply",
          data: body);

      print('Response: ${response.data}');
    } on DioException catch (e) {
      // كل أخطاء Dio بتيجي هنا
      if (e.type == DioExceptionType.connectionTimeout) {
        print('Connection Timeout');
      } else if (e.type == DioExceptionType.sendTimeout) {
        print('Send Timeout');
      } else if (e.type == DioExceptionType.receiveTimeout) {
        print('Receive Timeout');
      } else if (e.type == DioExceptionType.badResponse) {
        // في حالة السيرفر رجّع استجابة بخطأ (مثلاً 400 أو 500)
        final statusCode = e.response?.statusCode;
        final data = e.response?.data;
        print('Server error: $statusCode - $data');
      } else if (e.type == DioExceptionType.cancel) {
        print('Request was cancelled');
      } else if (e.type == DioExceptionType.unknown) {
        print('Unknown error: ${e.message}');
      } else {
        print('Other Dio error: ${e.message}');
      }
    } catch (e) {
      // أي خطأ ثاني غير Dio
      print('Unexpected error: $e');
    }

    var response = await dio.post(
        "https://sagr.libraryrajab.com/api/v1/event/apply",
        data: body);

    if (response.statusCode == 200) {
      return response;
    } else {
      throw ServerException();
    }
  }

  @override
  Future<Response> uploadVoiceMessage(Map<String, dynamic> body) async {
//  try {
//     final    response = await dio.post("https://seashell-octopus-307135.hostingersite.com/api/v1/event/apply",data: body);

//     print('Response: ${response.data}');
//   } on DioException catch (e) {
//     // كل أخطاء Dio بتيجي هنا
//     if (e.type == DioExceptionType.connectionTimeout) {
//       print('Connection Timeout');
//     } else if (e.type == DioExceptionType.sendTimeout) {
//       print('Send Timeout');
//     } else if (e.type == DioExceptionType.receiveTimeout) {
//       print('Receive Timeout');
//     } else if (e.type == DioExceptionType.badResponse) {
//       // في حالة السيرفر رجّع استجابة بخطأ (مثلاً 400 أو 500)
//       final statusCode = e.response?.statusCode;
//       final data = e.response?.data;
//       print('Server error: $statusCode - $data');
//     } else if (e.type == DioExceptionType.cancel) {
//       print('Request was cancelled');
//     } else if (e.type == DioExceptionType.unknown) {
//       print('Unknown error: ${e.message}');
//     } else {
//       print('Other Dio error: ${e.message}');
//     }
//   } catch (e) {
//     // أي خطأ ثاني غير Dio
//     print('Unexpected error: $e');
//   }

    try {
      dio.options.contentType = "multipart/form-data";
      // set image append to formData
      final multiPartFile = await dioHttp.MultipartFile.fromFile(
        body['voice_file'],
        filename: body['voice_file'].split('/').last,
      );

      formData.FormData preparedFormData = formData.FormData.fromMap({
        'user_id': body['user_id'],
        'conversation_id': body['conversation_id'],
        'text': body['type'] == 'voice' ? 'voiceMessage' : body['text'],
        'type': body['type'],
        "voice_file": multiPartFile,
      });

      print("ERROR 🔥🔥🔥🔥🔥🔥");
      print(multiPartFile);
      print("ERROR 🔥🔥🔥🔥🔥🔥");

      var response = await dio.post(
          "https://seashell-octopus-307135.hostingersite.com/api/v1/conversations/1/messages",
          data: preparedFormData);
    } on dioHttp.DioException catch (e) {
      print(e.response?.statusCode);
      // print(e.response?.data);

      throw ValidationException(e.response?.data);
    }

    throw ServerException();

    // if (response.statusCode == 200) {

    //  return response;

    // } else {

    //   throw ServerException();

    // }
  }

  Future<Response> sendMessage(Map<String, dynamic> body) async {
//  try {
//     // Validate file type before attempting upload
//     String filePath = body['voice_file'];
//     String fileName = filePath.split('/').last;
//     String fileExtension = fileName.split('.').last.toLowerCase();

//     print("🤌");

//     print(filePath);

//     print("🤌");

// // 'Content-Type': 'multipart/form-data',

//     // Check if file exists
//     File file = File(filePath);
//     if (!await file.exists()) {
//       throw ValidationException({
//         'errors': {
//           'voice_file': ['The voice file does not exist at the specified path.👍']
//         }
//       });
//     }

//     // Check if file extension is one of the allowed types
//     List<String> allowedExtensions = ['mp3', 'wav', 'm4a'];
//     if (!allowedExtensions.contains(fileExtension)) {
//       throw ValidationException({
//         'errors': {
//           'voice_file': ['The voice file must be of type: mp3, wav, or m4a. Found 😋: $fileExtension']
//         }
//       });
//     }

//     // Check file size (max 10MB according to server validation)
//     int fileSize = await file.length();
//     if (fileSize > 10 * 1024 * 1024) { // 10MB in bytes
//       throw ValidationException({
//         'errors': {
//           'voice_file': ['The voice file must be less than 10MB.']
//         }
//       });
//     }

//     // Set proper content type for the request
//     dio.options.contentType = "multipart/form-data";
//     // dio.options.headers = {
//     //   "Accept": "application/json",
//     // };

//     // Determine MIME type based on file extension for Laravel compatibility
//     String mimeTypeStr;

//     switch (fileExtension) {
//       case 'mp3':
//         mimeTypeStr = 'audio/mpeg'; // Standard MIME type for MP3
//         break;
//       case 'wav':
//         mimeTypeStr = 'audio/wav'; // Standard MIME type for WAV
//         break;
//       case 'm4a':
//         // Laravel specifically expects one of these for m4a
//         mimeTypeStr = 'audio/mp4'; // This is what Laravel's mime validation often expects for m4a
//         break;
//       default:
//         mimeTypeStr = 'audio/mpeg'; // fallback
//     }

//     // Let's try to detect the actual MIME type from the file content (requires mime package)
//     // String? detectedMimeType = lookupMimeType(filePath);
//     // if (detectedMimeType != null) {
//     //   print("Detected MIME type: $detectedMimeType");
//     //   // Uncomment this if you want to use the detected MIME type
//     //   // mimeTypeStr = detectedMimeType;
//     // }

//     // Create MediaType object from the http_parser package
//     // final mediaType = MediaType.parse(mimeTypeStr);

//     // Create the multipart file with MediaType
//     final multiPartFile = await dioHttp.MultipartFile.fromFile(
//       filePath,
//       filename: fileName,
//       contentType: MediaType('audio', 'm4a'),
//     );

//     // Create form data with all required fields
//     // formData.FormData preparedFormData = formData.FormData.fromMap({
//     //   'user_id': body['user_id'],
//     //   'conversation_id': body['conversation_id'],
//     //   'text': body['type'] == 'voice' ? 'voiceMessage' : body['text'],
//     //   'type': body['type'],
//     //   'voice_file': multiPartFile,
//     // });

//     // For debugging, print the file details
//     print("Sending request with the following data:");
//     print("user_id: ${body['user_id']}");
//     print("conversation_id: ${body['conversation_id']}");
//     print("text: ${body['type'] == 'voice' ? 'voiceMessage' : body['text']}");
//     print("type: ${body['type']}");
//     print("voice_file: $fileName ($mimeTypeStr)");
//     print("file size: ${fileSize/1024} KB");
//     print("file exists: ${await file.exists()}");

//     // Create form data with all required fields - make sure voice_file is the exact field name expected by Laravel
//     formData.FormData preparedFormData = formData.FormData.fromMap({
//       'user_id': body['user_id'],
//       'conversation_id': body['conversation_id'],
//       'text': body['type'] == 'voice' ? '' : body['text'],  // Send empty string for voice messages
//       'type': body['type'],
//       'voice_file': multiPartFile,  // This field name must match Laravel's expected input name
//     });

//       print("😋😋😋😋😋😋😋");

//       print(preparedFormData);
//       print("😋😋😋😋😋😋😋");

//     // Make the API request with detailed error logging
//     try {
//       var response = await dio.post(
//         "https://seashell-octopus-307135.hostingersite.com/api/v1/conversations/${body['conversation_id']}/messages",
//         data: preparedFormData,
//       );

//       // Handle successful response
//       if (response.statusCode == 200 || response.statusCode == 201) {
//         return response.data;
//       } else {
//         throw ServerException();
//       }
//     } on dioHttp.DioException catch (e) {
//       print("DioException: ${e.response?.statusCode}");
//       print("Error data: ${e.response?.data}");
//       print("Request: ${e.requestOptions.uri}");
//       print("Headers: ${e.requestOptions.headers}");

//       if (e.response?.statusCode == 422) {
//         print("Validation error details: ${e.response?.data}");
//         throw ValidationException(e.response?.data);
//       } else {
//         throw ServerException();
//       }
//     }
//     var response = await dio.post(
//       "https://seashell-octopus-307135.hostingersite.com/api/v1/conversations/${body['conversation_id']}/messages",
//       data: preparedFormData,
//     );

//     // Handle successful response
//     if (response.statusCode == 200 || response.statusCode == 201) {
//       return response.data;
//     } else {
//       throw ServerException();
//     }

//   } catch (e) {
//     print("Unexpected error: $e");
//     throw ServerException();
//   }

    // try {
    //   // Validate file type before attempting upload
    //   String filePath = body['voice_file'];
    //   String fileName = filePath.split('/').last;
    //   String fileExtension = fileName.split('.').last.toLowerCase();

    //   // Check if file exists
    //   File file = File(filePath);
    //   if (!await file.exists()) {
    //     throw ValidationException({
    //       'errors': {
    //         'voice_file': ['The voice file does not exist at the specified path.']
    //       }
    //     });
    //   }

    //   // Check if file extension is one of the allowed types
    //   List<String> allowedExtensions = ['mp3', 'wav', 'm4a'];
    //   if (!allowedExtensions.contains(fileExtension)) {
    //     throw ValidationException({
    //       'errors': {
    //         'voice_file': ['The voice file must be of type: mp3, wav, or m4a. Found: $fileExtension']
    //       }
    //     });
    //   }

    //   // Check file size (max 10MB according to server validation)
    //   int fileSize = await file.length();
    //   if (fileSize > 10 * 1024 * 1024) { // 10MB in bytes
    //     throw ValidationException({
    //       'errors': {
    //         'voice_file': ['The voice file must be less than 10MB.']
    //       }
    //     });
    //   }

    //   // Set proper content type for the request
    //   dio.options.contentType = "multipart/form-data";
    //   // dio.options.headers = {
    //   //   "Content-Type": "application/json",
    //   //   "Accept": "application/json",
    //   //   'Accepted-Language': 'ar',
    //   //   "Authorization" : "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL3NlYXNoZWxsLW9jdG9wdXMtMzA3MTM1Lmhvc3RpbmdlcnNpdGUuY29tL3B1YmxpYy9hcGkvdjEvYXV0aC9sb2dpbiIsImlhdCI6MTc0NzU1NTAyNCwiZXhwIjoxNzgzNTU1MDI0LCJuYmYiOjE3NDc1NTUwMjQsImp0aSI6IjRvc3JJWW9IZVpVZFd3bEEiLCJzdWIiOiI5MiIsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.kFPufGFKV5O_f_23-BgJyNN-xcnOiJsKBS2F-dp0Cbw"
    //   // };

    //   // Create multipart file with correct MIME type
    //   // String mimeTypeStr;
    //   // switch (fileExtension) {
    //   //   case 'mp3':
    //   //     mimeTypeStr = 'audio/mpeg';
    //   //     break;
    //   //   case 'wav':
    //   //     mimeTypeStr = 'audio/wav';
    //   //     break;
    //   //   case 'm4a':
    //   //     mimeTypeStr = 'audio/x-m4a';  // Using standard MIME type for m4a
    //   //     break;
    //   //   default:
    //   //     mimeTypeStr = 'audio/mpeg'; // fallback
    //   // }

    //   // Create MediaType object from the http_parser package
    //   // final mediaType = MediaType.parse(mimeTypeStr);

    //   // Create the multipart file with MediaType
    //   final multiPartFile = await dioHttp.MultipartFile.fromFile(
    //     filePath,
    //     filename: fileName,
    //     // contentType: mediaType,
    //   );

    //   // Create form data with all required fields
    //   formData.FormData preparedFormData = formData.FormData.fromMap({
    //     'user_id': body['user_id'],
    //     'conversation_id': body['conversation_id'],
    //     'text': body['type'] == 'voice' ? 'voiceMessage' : body['text'],
    //     'type': body['type'],
    //     'voice_file': multiPartFile,
    //   });

    //   // For debugging, print the file details
    //   print("Sending request with the following data:");
    //   print("user_id: ${body['user_id']}");
    //   print("conversation_id: ${body['conversation_id']}");
    //   print("text: ${body['type'] == 'voice' ? 'voiceMessage' : body['text']}");
    //   print("type: ${body['type']}");
    //   // print("voice_file: $fileName ($mimeTypeStr)");
    //   print("file size: ${fileSize/1024} KB");
    //   print("file exists: ${await file.exists()}");

    //   // // Create form data with all required fields - make sure voice_file is the exact field name expected by Laravel
    //   // formData.FormData preparedFormData = formData.FormData.fromMap({
    //   //   'user_id': body['user_id'],
    //   //   'conversation_id': body['conversation_id'],
    //   //   'text': body['type'] == 'voice' ? '' : body['text'],  // Send empty string for voice messages
    //   //   'type': body['type'],
    //   //   'voice_file': multiPartFile,  // This field name must match Laravel's expected input name
    //   // });

    //   // Make the API request with detailed error logging
    //   try {
    //     var response = await dio.post(
    //       "https://seashell-octopus-307135.hostingersite.com/api/v1/conversations/${body['conversation_id']}/messages",
    //       data: preparedFormData,
    //     );

    //     // Handle successful response
    //     if (response.statusCode == 200 || response.statusCode == 201) {
    //       return response.data;
    //     } else {
    //       throw ServerException();
    //     }
    //   } on dioHttp.DioException catch (e) {
    //     print("DioException: ${e.response?.statusCode}");
    //     print("Error data: ${e.response?.data}");
    //     print("Request: ${e.requestOptions.uri}");
    //     print("Headers: ${e.requestOptions.headers}");

    //     if (e.response?.statusCode == 422) {
    //       print("Validation error details: ${e.response?.data}");
    //       throw ValidationException(e.response?.data);
    //     } else {
    //       throw ServerException();
    //     }
    //   }
    //   var response = await dio.post(
    //     "https://seashell-octopus-307135.hostingersite.com/api/v1/conversations/${body['conversation_id']}/messages",
    //     data: preparedFormData,
    //   );

    //   // Handle successful response
    //   if (response.statusCode == 200 || response.statusCode == 201) {
    //     return response.data;
    //   } else {
    //     throw ServerException();
    //   }

    // } catch (e) {
    //   print("Unexpected error: $e");
    //   throw ServerException();
    // }

    try {
      if (body['type'] == 'voice') {
        // Validate file type before attempting upload
        String filePath = body['voice_file'];
        String fileName = filePath.split('/').last;
        String fileExtension = fileName.split('.').last.toLowerCase();

        // Check if file extension is one of the allowed types
        List<String> allowedExtensions = ['mp3', 'wav', 'm4a'];
        if (!allowedExtensions.contains(fileExtension)) {
          throw ValidationException({
            'errors': {
              'voice_file': [
                'The voice file must be of type: mp3, wav, or m4a. Found: $fileExtension'
              ]
            }
          });
        }

        dio.options.contentType = "multipart/form-data";

        // Create multipart file from the voice file path with correct MIME type
        String mimeTypeStr;
        switch (fileExtension) {
          case 'mp3':
            mimeTypeStr = 'audio/mpeg';
            break;
          case 'wav':
            mimeTypeStr = 'audio/wav';
            break;
          case 'm4a':
            mimeTypeStr = 'audio/m4a';
            break;
          default:
            mimeTypeStr = 'audio/mpeg'; // fallback
        }

        // Create MediaType object from the http_parser package
        final mediaType = MediaType.parse(mimeTypeStr);

        // Create the multipart file with MediaType
        final multiPartFile = await dioHttp.MultipartFile.fromFile(
          filePath,
          filename: fileName,
          contentType: mediaType,
        );

        // Create form data with all required fields
        formData.FormData preparedFormData = formData.FormData.fromMap({
          'user_id': body['user_id'],
          'conversation_id': body['conversation_id'],
          'text': body['type'] == 'voice' ? 'voiceMessage' : body['text'],
          'type': body['type'],
          'voice_file': multiPartFile,
        });

        print("Sending request with the following data:");
        print("user_id: ${body['user_id']}");
        print("conversation_id: ${body['conversation_id']}");
        print(
            "text: ${body['type'] == 'voice' ? 'voiceMessage' : body['text']}");
        print("type: ${body['type']}");
        print("voice_file: $fileName ($mimeTypeStr)");

        // Make the API request
        var response = await dio.post(
          "https://sagr.libraryrajab.com/api/v1/conversations/${body['conversation_id']}/messages",
          data: preparedFormData,
        );

        // Handle successful response
        if (response.statusCode == 200 || response.statusCode == 201) {
          return response.data;
        } else {
          throw ServerException();
        }
      } else {
        formData.FormData preparedFormData = formData.FormData.fromMap({
          'user_id': body['user_id'],
          'conversation_id': body['conversation_id'],
          'text': body['type'] == 'voice' ? 'voiceMessage' : body['text'],
          'type': body['type'],
        });

        // Make the API request
        var response = await dio.post(
          "https://sagr.libraryrajab.com/api/v1/conversations/${body['conversation_id']}/messages",
          data: preparedFormData,
        );

        // Handle successful response
        if (response.statusCode == 200 || response.statusCode == 201) {
          return response.data;
        } else {
          throw ServerException();
        }
      }
    } on dioHttp.DioException catch (e) {

      print("DioException: ${e.response?.statusCode}");
      
      print("Error data: ${e.response?.data}");

      if (e.response?.statusCode == 422) {
        // print("Validation error: ${e.response?.data}");
        throw ValidationException(e.response?.data);
      } else {
        throw ServerException();
      }
    } catch (e) {
      print("Unexpected error: $e");
      throw ServerException();
    }
  }
}
