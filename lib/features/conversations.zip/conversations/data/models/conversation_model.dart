
import 'package:sagr/models/user_model.dart';

import '../../domain/entities/conversation.dart';

import 'message_model.dart';

enum ConversationType { private, group }

class ConversationModel extends Conversation {


  final int id;

  final String? name;

  final String? type;

  final String? photo;

  final int? createdBy;

  final MessageModel? lastMessage;

  final int? unreadCount;

    final String? createdAt;

  final String? updatedAt;

  final List<UserModel> users;


  const ConversationModel(
    {
    required this.id,
    this.name,
    this.type,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
    this.lastMessage,
    this.unreadCount,
    this.photo,
    this.users = const [],
  }) : super(id: id, name: name, type: type, createdBy: createdBy, unreadCount: unreadCount, photo: photo);

  factory ConversationModel.fromJson(Map<String, dynamic> json) {

     final List<UserModel> usersList = [];
    if (json['users'] != null) {
      json['users'].forEach((user) {
        usersList.add(UserModel.fromJson(user));
      });
    }

    return ConversationModel(
      id: json['id'],
      name: json['name'] ?? "",
      type: json['type'] ?? 'private',
      createdBy: json['createdBy'],
      createdAt: json['created_at']??"",
      updatedAt: json['updated_at']??"",
      unreadCount: json['unreadCount']??0,
      users: usersList,
      lastMessage: MessageModel.fromJson(json['lastMessage']),

    );
  }

  @override
  Map<String, dynamic> toJson() {
    return {'id': id, 'name': name, 'type': type, 'createdBy': createdBy, 'unreadCount': unreadCount,'users': users.map((user) => user.toJson()).toList(), };
  }

  @override
  String toString() {
    return name!;
  }


Conversation copyWith({
    int? id,
    String? name,
    String? type,
    String? description,
    String? photo,
    int? createdBy,
    int? unreadCount,
    String? createdAt,
    String? updatedAt,
    MessageModel? lastMessage

  }) {
    return Conversation(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      photo: photo??this.photo,
      createdBy: createdBy??this.createdBy,
      unreadCount: unreadCount??this.unreadCount,
      createdAt: createdAt??this.createdAt,
      updatedAt: updatedAt??this.updatedAt,
      lastMessage: lastMessage??this.lastMessage
    
    );
  }


  // Helper to get the display name for the conversation
  String getDisplayName() {
    if (type == 'private') {
      // For private chats, display the other user's name
      final otherUsers = users.where((user) => user.id != createdBy);
      return otherUsers.isNotEmpty ? otherUsers.first.name! : 'Unknown';
    } else {
      // For group chats, use the group name
      return name ?? 'Group Chat';
    }
  }

  // Helper to get the display image for the conversation
  // String? getDisplayImage() {
  //   if (type == ConversationType.private) {
  //     // For private chats, display the other user's profile photo
  //     final otherUsers = users.where((user) => user.id != createdBy);
  //     return otherUsers.isNotEmpty ? otherUsers.first.profilePhoto : null;
  //   } else {
  //     // For group chats, use the group photo
  //     return photo;
  //   }
  }
  

