import 'package:sagr/features/events/data/models/period_model.dart';

import '../../domain/entities/event.dart';

class EventModel extends Event {
  

  final int? id;

  final String? name;

  final String? description;

  final String? address;

  final String? logo;

  final String? datetime;

  final String? date;

  final String? time;

  final String? ago;

  final String? preparing;

  final List? periods;

  final String? appliedStatus;

  final String? nationalID;

  const EventModel(
      {this.id,
      this.name,
      this.description,
      this.logo,
      this.datetime,
      this.date,
      this.time,
      this.address,
      this.ago,
      this.preparing,
      this.appliedStatus,
      this.nationalID,
      this.periods})
      : super(
            id: id,
            name: name,
            description: description,
            logo: logo,
            datetime: datetime,
            date: date,
            time: time,
            address: address,
            ago: ago,
            preparing: preparing,
            appliedStatus: appliedStatus,
            nationalID: nationalID,
            periods: periods);

  factory EventModel.fromJson(Map<String, dynamic> json) {
    List<PeriodModel> periodsResults = [];

    if (json['periods'] != null) {
      json['periods'].forEach((child) {
        periodsResults.add(PeriodModel.fromMap(child));
      });
    }

    return EventModel(
        id: json['id'],
        name: json['name'] ?? "",
        description: json['description'],
        logo: json['logo'],
        datetime: json['datetime'],
        date: json['date'],
        time: json['time'],
        address: json['address'],
        ago: json['ago'],
        preparing: json['preparing'],
        appliedStatus: json['appliedStatus'] ?? 'undefined',
        nationalID: json['nationalID'] ?? '',
        periods: periodsResults);
  }

  @override
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'logo': logo,
      'datetime': datetime,
      'date': date,
      'time': time,
      'address': address,
      'ago': ago,
      'preparing': preparing,
      'periods': periods,
      'appliedStatus': appliedStatus,
      'nationalID': nationalID
    };
  }

  @override
  String toString() {
    return name!;
  }
}



// import 'package:sagr/features/events/data/models/period_model.dart';
// import '../../domain/entities/event.dart';

// class EventModel extends Event {
//   const EventModel({
//     super.id,
//     super.name,
//     super.description,
//     super.address,
//     super.logo,
//     super.datetime,
//     super.date,
//     super.time,
//     super.ago,
//     super.preparing,
//     super.appliedStatus = null,
//     List<PeriodModel> super.periods = const [],
//   });

//   factory EventModel.fromJson(Map<String, dynamic> json) {
//     return EventModel(
//       id: json['id'],
//       name: json['name'] ?? '',
//       description: json['description'],
//       logo: json['logo'],
//       datetime: json['datetime'],
//       date: json['date'],
//       time: json['time'],
//       address: json['address'],
//       ago: json['ago'],
//       preparing: json['preparing'],
//       appliedStatus: json['appliedStatus'] ?? 'undefined',
//       periods: (json['periods'] as List<dynamic>?)
//               ?.map((e) => PeriodModel.fromMap(e))
//               .toList() ??
//           [],
//     );
//   }

//   @override
//   Map<String, dynamic> toJson() {
//     return {
//       'id': id,
//       'name': name,
//       'description': description,
//       'logo': logo,
//       'datetime': datetime,
//       'date': date,
//       'time': time,
//       'address': address,
//       'ago': ago,
//       'preparing': preparing,
//       'appliedStatus': appliedStatus,
//       'periods': periods!.map((e) => e.toJson()).toList(),
//     };
//   }

//   @override
//   String toString() => name ?? '';
// }
