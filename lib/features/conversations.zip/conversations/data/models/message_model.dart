import 'dart:io';

import 'package:get_storage/get_storage.dart';
import '../../domain/entities/message.dart';

/// [MessageStatus] defines the current state of the message
/// if you are sender sending a message then, the
enum MessageStatus {
  read,
  delivered,
  undelivered,
  pending;

  static MessageStatus? tryParse(String? value) {
    final status = value?.trim().toLowerCase();
    if (status?.isEmpty ?? true) return null;
    if (status == read.name) {
      return read;
    } else if (status == delivered.name) {
      return delivered;
    } else if (status == undelivered.name) {
      return undelivered;
    } else if (status == pending.name) {
      return pending;
    }
    return null;
  }
}

class MessageModel extends Message {
  final int id;

  final String? text;

  final int? userId;

  final int? conversationId;

  final String? voicePath;

  final File? voiceFile;

  // final String? content;

  // final String? message;

  final String? type;

  // final UserModel? user;

  // final bool? unread;

  final DateTime? createdAt;

  // final String? sentBy;

  // final MessageStatus? status;

  const MessageModel(
      {required this.id,
      // this.content,
      this.type,
      // this.user,
      // this.unread,
      this.createdAt,
      this.userId,
      this.conversationId,
      this.voicePath,
      this.voiceFile,
      // this.status,
      this.text})
      : super(
            id: id,
            text: text,
            userId: userId,
            conversationId: conversationId,
            createdAt: createdAt);

  factory MessageModel.fromJson(Map<String, dynamic> json) {
    return MessageModel(
      id: json['id'],
      text: json['text'],
      userId: json['user_id'],
      conversationId: json['conversation_id'],
      voicePath: json['voice_file'],
      // voiceFile: json['voice_file'],
      // content: json['content']??"",
      // message: json['content']??"",

      type: json['type'] ?? 'text',

      createdAt: DateTime.parse(
      json['created_at'] ?? DateTime.now().toIso8601String()),
      // sentBy:json['sentBy'].toString(),
      // status:MessageStatus.pending,
      // user: UserModel.fromJson({"id": 92,"name": 'Hassan Saeed'})
    );
  }

  @override
  Map<String, dynamic> toJson() {
    // return {'id': id, 'content': content, 'type': type, 'user': user, 'message':message, 'text': text};
    return {
      'id': id,
      'text': text,
      'type': type,
      'createdAt': createdAt,
      'userId': userId,
      'conversationId': conversationId,
      'voiceFile': voiceFile
    };
  }

// Helper to get the display name for the conversation
  String getSenderName() {
    // For private chats, display the other user's name

    return GetStorage().read('userData')['name'];
  }

  int getCurrentUserId() {
    return GetStorage().read('userData')['id'];
  }
}
