import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'dart:math' as math;
import 'dart:async';

class WhatsAppVoicePlayer extends StatefulWidget {
  final String audioUrl;
  final bool isOutgoing; // true for sent messages, false for received
  final String timestamp;
  final Duration? duration;
  
  const WhatsAppVoicePlayer({
    Key? key,
    required this.audioUrl,
    this.isOutgoing = true,
    this.timestamp = '',
    this.duration,
  }) : super(key: key);

  @override
  State<WhatsAppVoicePlayer> createState() => _WhatsAppVoicePlayerState();
}

class _WhatsAppVoicePlayerState extends State<WhatsAppVoicePlayer>
    with TickerProviderStateMixin {
  late AudioPlayer _audioPlayer;
  
  // Animation controllers
  late AnimationController _playButtonController;
  late AnimationController _waveAnimationController;
  late Animation<double> _playButtonAnimation;
  
  // Audio state
  bool _isPlaying = false;
  bool _isLoading = false;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  double _playbackSpeed = 1.0;
  
  // Waveform data (simulated)
  List<double> _waveformData = [];
  Timer? _waveformTimer;
  
  @override
  void initState() {
    super.initState();
    _initializePlayer();
    _initializeAnimations();
    _generateWaveformData();
  }

  void _initializePlayer() {
    _audioPlayer = AudioPlayer();
    
    // Listen to player state changes
    _audioPlayer.playerStateStream.listen((state) {
      if (mounted) {
        setState(() {
          _isLoading = state.processingState == ProcessingState.loading ||
                      state.processingState == ProcessingState.buffering;
          _isPlaying = state.playing;
        });
        
        if (_isPlaying) {
          _playButtonController.forward();
          _waveAnimationController.repeat();
        } else {
          _playButtonController.reverse();
          _waveAnimationController.stop();
        }
      }
    });
    
    // Listen to duration changes
    _audioPlayer.durationStream.listen((duration) {
      if (mounted && duration != null) {
        setState(() {
          _duration = duration;
        });
      }
    });
    
    // Listen to position changes
    _audioPlayer.positionStream.listen((position) {
      if (mounted) {
        setState(() {
          _position = position;
        });
      }
    });
    
    // Auto-pause when finished
    _audioPlayer.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _seekToStart();
      }
    });
  }

  void _initializeAnimations() {
    _playButtonController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    
    _waveAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _playButtonAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _playButtonController,
      curve: Curves.easeInOut,
    ));
  }

  void _generateWaveformData() {
    // Generate realistic waveform data
    final random = math.Random();
    _waveformData = List.generate(40, (index) {
      // Create more realistic voice-like waveform
      final baseAmplitude = math.sin(index * 0.3) * 0.3 + 0.4;
      final randomVariation = random.nextDouble() * 0.4;
      return (baseAmplitude + randomVariation).clamp(0.1, 0.9);
    });
  }

  Future<void> _togglePlayPause() async {
    try {
      if (_isPlaying) {
        await _audioPlayer.pause();
      } else {
        if (_position >= _duration && _duration > Duration.zero) {
          await _audioPlayer.seek(Duration.zero);
        }
        
        if (_audioPlayer.audioSource == null) {
          await _audioPlayer.setUrl(widget.audioUrl);
        }
        
        await _audioPlayer.play();
      }
    } catch (e) {
      _showError('Failed to play audio: $e');
    }
  }

  Future<void> _seekToStart() async {
    await _audioPlayer.seek(Duration.zero);
    await _audioPlayer.pause();
  }

  void _changePlaybackSpeed() {
    setState(() {
      if (_playbackSpeed == 1.0) {
        _playbackSpeed = 1.5;
      } else if (_playbackSpeed == 1.5) {
        _playbackSpeed = 2.0;
      } else {
        _playbackSpeed = 1.0;
      }
    });
    _audioPlayer.setSpeed(_playbackSpeed);
  }

  void _showError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  double get _progress {
    if (_duration.inMilliseconds <= 0) return 0.0;
    return (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0);
  }

  @override
  void dispose() {
    _playButtonController.dispose();
    _waveAnimationController.dispose();
    _waveformTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isOutgoing = widget.isOutgoing;
    final backgroundColor = isOutgoing ? const  Color.fromARGB(255, 66, 141, 227) : Colors.white;
    final textColor = isOutgoing ? Colors.white : Colors.black87;
    final iconColor = isOutgoing ? Colors.white : const Color.fromARGB(255, 66, 141, 227);


    // final backgroundColor = isOutgoing ? const Color(0xFF128C7E) : Colors.white;
    // final textColor = isOutgoing ? Colors.white : Colors.black87;
    // final iconColor = isOutgoing ? Colors.white : const Color(0xFF128C7E);

    return Container(
      margin: EdgeInsets.only(
        left: isOutgoing ? 60 : 10,
        right: isOutgoing ? 10 : 60,
        top: 3,
        bottom: 3,
      ),
      child: Align(
        alignment: isOutgoing ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(20),
              topRight: const Radius.circular(20),
              bottomLeft: Radius.circular(isOutgoing ? 20 : 5),
              bottomRight: Radius.circular(isOutgoing ? 5 : 20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 5,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Play/Pause Button
              GestureDetector(
                onTap: _togglePlayPause,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: _isLoading
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(iconColor),
                          ),
                        )
                      : AnimatedBuilder(
                          animation: _playButtonAnimation,
                          builder: (context, child) {
                            return Icon(
                              _playButtonAnimation.value > 0.5
                                  ? Icons.pause
                                  : Icons.play_arrow,
                              color: iconColor,
                              size: 24,
                            );
                          },
                        ),
                ),
              ),
              
              const SizedBox(width: 8),
              
              // Waveform Visualization
              Expanded(
                child: Container(
                  height: 40,
                  child: AnimatedBuilder(
                    animation: _waveAnimationController,
                    builder: (context, child) {
                      return CustomPaint(
                        painter: WaveformPainter(
                          waveformData: _waveformData,
                          progress: _progress,
                          isPlaying: _isPlaying,
                          animationValue: _waveAnimationController.value,
                          color: iconColor,
                        ),
                        size: Size.infinite,
                      );
                    },
                  ),
                ),
              ),
              
              const SizedBox(width: 8),
              
              // Duration and Speed Control
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Duration
                  Text(
                    _isPlaying || _position > Duration.zero
                        ? _formatDuration(_duration - _position)
                        : _formatDuration(widget.duration ?? _duration),
                    style: TextStyle(
                      color: textColor.withOpacity(0.7),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  
                  const SizedBox(height: 2),
                  
                  // Speed Control
                  GestureDetector(
                    onTap: _changePlaybackSpeed,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: iconColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${_playbackSpeed}x',
                        style: TextStyle(
                          color: iconColor,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(width: 4),
              
              // Message status (for outgoing messages)
              if (isOutgoing) ...[
                Icon(
                  Icons.done_all,
                  size: 16,
                  color: Colors.blue[300], // Read status
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// Custom painter for waveform
class WaveformPainter extends CustomPainter {
  final List<double> waveformData;
  final double progress;
  final bool isPlaying;
  final double animationValue;
  final Color color;

  WaveformPainter({
    required this.waveformData,
    required this.progress,
    required this.isPlaying,
    required this.animationValue,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2;

    final barWidth = size.width / waveformData.length;
    final centerY = size.height / 2;

    for (int i = 0; i < waveformData.length; i++) {
      final x = i * barWidth + barWidth / 2;
      final barHeight = waveformData[i] * size.height * 0.8;
      
      // Determine if this bar should be "played" (colored)
      final barProgress = (i + 1) / waveformData.length;
      final isPlayed = barProgress <= progress;
      
      // Add animation effect when playing
      double animatedHeight = barHeight;
      if (isPlaying && isPlayed) {
        final animationOffset = math.sin(animationValue * 2 * math.pi + i * 0.5) * 0.1;
        animatedHeight = barHeight * (1.0 + animationOffset);
      }
      
      paint.color = isPlayed 
          ? color 
          : color.withOpacity(0.3);
      
      canvas.drawLine(
        Offset(x, centerY - animatedHeight / 2),
        Offset(x, centerY + animatedHeight / 2),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}