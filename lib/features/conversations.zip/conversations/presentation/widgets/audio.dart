import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math' as math;
import 'dart:async';

class AudioPlayerScreen extends StatefulWidget {
  final String audioFilePath; // Path to your M4A file
  
  const AudioPlayerScreen({Key? key, required this.audioFilePath}) : super(key: key);

  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> with TickerProviderStateMixin {
  late AudioPlayer audioPlayer;
  bool isPlaying = false;
  Duration duration = Duration.zero;
  Duration position = Duration.zero;
  Duration? savedStopTime;
  
  // Wave animation variables
  late AnimationController _waveController;
  Timer? _audioVisualizationTimer;
  List<double> waveformData = List.generate(50, (index) => 0.0);
  double currentAmplitude = 0.0;
  List<double> frequencyBands = List.generate(5, (index) => 0.0); // Low to High frequency bands

  @override
  void initState() {
    super.initState();
    audioPlayer = AudioPlayer();
    _waveController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    setupAudioPlayer();
    loadSavedStopTime();
    startAudioVisualization();
  }

  void setupAudioPlayer() {
    // Listen to audio duration changes
    audioPlayer.onDurationChanged.listen((Duration d) {
      setState(() {
        duration = d;
      });
    });

    // Listen to audio position changes
    audioPlayer.onPositionChanged.listen((Duration p) {
      setState(() {
        position = p;
      });
    });

    // Listen to player state changes
    audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
      setState(() {
        isPlaying = state == PlayerState.playing;
      });
      
      // Control wave animation based on play state
      if (isPlaying) {
        _waveController.repeat();
      } else {
        _waveController.stop();
        // Gradually reduce wave amplitude when stopped
        _reduceWaveAmplitude();
      }
    });

    // Listen to completion
    audioPlayer.onPlayerComplete.listen((event) {
      setState(() {
        isPlaying = false;
        position = Duration.zero;
      });
    });
  }

  // Start audio visualization simulation
  void startAudioVisualization() {
    _audioVisualizationTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (mounted && isPlaying) {
        _updateWaveformData();
      }
    });
  }

  // Update waveform data with simulated audio levels
  void _updateWaveformData() {
    if (!mounted) return;
    
    final random = math.Random();
    
    // Simulate different frequency bands (bass to treble)
    for (int i = 0; i < frequencyBands.length; i++) {
      // Higher frequencies tend to have lower amplitude in most music
      double baseAmplitude = (5 - i) / 5.0;
      frequencyBands[i] = baseAmplitude * (0.2 + random.nextDouble() * 0.8);
    }
    
    // Update main waveform display
    setState(() {
      // Shift existing data left
      for (int i = 0; i < waveformData.length - 1; i++) {
        waveformData[i] = waveformData[i + 1];
      }
      
      // Add new data point (combination of all frequency bands)
      double combinedAmplitude = frequencyBands.reduce((a, b) => a + b) / frequencyBands.length;
      waveformData[waveformData.length - 1] = combinedAmplitude;
      currentAmplitude = combinedAmplitude;
    });
  }

  // Gradually reduce wave amplitude when stopped
  void _reduceWaveAmplitude() {
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      
      if (!isPlaying) {
        setState(() {
          for (int i = 0; i < waveformData.length; i++) {
            waveformData[i] *= 0.9; // Gradually reduce
          }
          for (int i = 0; i < frequencyBands.length; i++) {
            frequencyBands[i] *= 0.9;
          }
          currentAmplitude *= 0.9;
        });
        
        if (currentAmplitude < 0.01) {
          timer.cancel();
        }
      } else {
        timer.cancel();
      }
    });
  }

  // Load saved stop time from SharedPreferences
  Future<void> loadSavedStopTime() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedMilliseconds = prefs.getInt('saved_stop_time_${widget.audioFilePath}');
      if (savedMilliseconds != null && mounted) {
        setState(() {
          savedStopTime = Duration(milliseconds: savedMilliseconds);
        });
      }
    } catch (e) {
      print('Error loading saved stop time: $e');
    }
  }

  // Save stop time to SharedPreferences
  Future<void> saveStopTime(Duration stopTime) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('saved_stop_time_${widget.audioFilePath}', stopTime.inMilliseconds);
      
      if (mounted) {
        setState(() {
          savedStopTime = stopTime;
        });
        
        // Show confirmation
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Stop time saved: ${formatDuration(stopTime)}'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      print('Error saving stop time: $e');
    }
  }

  // Play audio
  Future<void> playAudio() async {
    try {
      if (widget.audioFilePath.startsWith('http')) {
        // For network files
        await audioPlayer.play(UrlSource(widget.audioFilePath));
      } else if (widget.audioFilePath.startsWith('assets/')) {
        // For asset files
        await audioPlayer.play(AssetSource(widget.audioFilePath.replaceFirst('assets/', '')));
      } else {
        // For local files
        await audioPlayer.play(DeviceFileSource(widget.audioFilePath));
      }
    } catch (e) {
      print('Error playing audio: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error playing audio: $e')),
        );
      }
    }
  }

  // Pause audio
  Future<void> pauseAudio() async {
    try {
      await audioPlayer.pause();
    } catch (e) {
      print('Error pausing audio: $e');
    }
  }

  // Stop audio and save stop time
  Future<void> stopAudio() async {
    try {
      final currentPosition = position;
      await audioPlayer.stop();
      await saveStopTime(currentPosition);
    } catch (e) {
      print('Error stopping audio: $e');
    }
  }

  // Replay from beginning
  Future<void> replayAudio() async {
    try {
      await audioPlayer.seek(Duration.zero);
      await playAudio();
    } catch (e) {
      print('Error replaying audio: $e');
    }
  }

  // Resume from saved stop time
  Future<void> resumeFromSavedTime() async {
    try {
      if (savedStopTime != null) {
        await audioPlayer.seek(savedStopTime!);
        await playAudio();
      }
    } catch (e) {
      print('Error resuming from saved time: $e');
    }
  }

  // Seek to specific position
  Future<void> seekTo(Duration seekPosition) async {
    try {
      await audioPlayer.seek(seekPosition);
    } catch (e) {
      print('Error seeking: $e');
    }
  }

  // Format duration for display
  String formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    
    if (duration.inHours > 0) {
      return '$hours:$minutes:$seconds';
    } else {
      return '$minutes:$seconds';
    }
  }

  // Build individual frequency bar
  Widget _buildFrequencyBar(String label, double amplitude, Color color) {
    return Column(
      children: [
        Container(
          height: 60,
          width: 20,
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(10),
          ),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 100),
                height: amplitude * 60,
                width: 20,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.5),
                      blurRadius: 4,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _waveController.dispose();
    _audioVisualizationTimer?.cancel();
    audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('M4A Audio Player'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      backgroundColor: Colors.grey[100],
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Audio file info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.audio_file,
                    size: 64,
                    color: Colors.deepPurple,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'M4A Audio File',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.audioFilePath.split('/').last,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 30),
            
            // Waveform Visualization
            Container(
              height: 120,
              margin: const EdgeInsets.symmetric(horizontal: 0),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.deepPurple.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: AnimatedBuilder(
                  animation: _waveController,
                  builder: (context, child) {
                    return CustomPaint(
                      painter: WaveformPainter(
                        waveformData: waveformData,
                        isPlaying: isPlaying,
                        animationValue: _waveController.value,
                      ),
                      size: Size.infinite,
                    );
                  },
                ),
              ),
            ),
            
            const SizedBox(height: 20),
            
            // Frequency Bands Display
            Container(
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.symmetric(horizontal: 0),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  const Text(
                    'Voice Frequency Analysis',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildFrequencyBar('Bass', frequencyBands.isNotEmpty ? frequencyBands[0] : 0.0, Colors.red),
                      _buildFrequencyBar('Low Mid', frequencyBands.length > 1 ? frequencyBands[1] : 0.0, Colors.orange),
                      _buildFrequencyBar('Mid', frequencyBands.length > 2 ? frequencyBands[2] : 0.0, Colors.yellow),
                      _buildFrequencyBar('High Mid', frequencyBands.length > 3 ? frequencyBands[3] : 0.0, Colors.lightGreen),
                      _buildFrequencyBar('Treble', frequencyBands.length > 4 ? frequencyBands[4] : 0.0, Colors.cyan),
                    ],
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 30),
            
            // Progress slider
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Slider(
                    min: 0,
                    max: duration.inSeconds.toDouble().clamp(0, double.infinity),
                    value: position.inSeconds.toDouble().clamp(0, duration.inSeconds.toDouble()),
                    activeColor: Colors.deepPurple,
                    onChanged: (value) async {
                      final newPosition = Duration(seconds: value.toInt());
                      await seekTo(newPosition);
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(formatDuration(position)),
                        Text(formatDuration(duration)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 30),
            
            // Main control buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Replay button
                ElevatedButton.icon(
                  onPressed: replayAudio,
                  icon: const Icon(Icons.replay),
                  label: const Text('Replay'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
                
                // Play/Pause button
                ElevatedButton.icon(
                  onPressed: isPlaying ? pauseAudio : playAudio,
                  icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
                  label: Text(isPlaying ? 'Pause' : 'Play'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
                
                // Stop button
                ElevatedButton.icon(
                  onPressed: stopAudio,
                  icon: const Icon(Icons.stop),
                  label: const Text('Stop'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 20),
            
            // Saved stop time section
            if (savedStopTime != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue[200]!),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.bookmark, color: Colors.blue),
                        const SizedBox(width: 8),
                        Text(
                          'Saved Stop Time: ${formatDuration(savedStopTime!)}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[700],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: resumeFromSavedTime,
                      icon: const Icon(Icons.play_arrow),
                      label: const Text('Resume from Saved Time'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// Custom painter for waveform visualization
class WaveformPainter extends CustomPainter {
  final List<double> waveformData;
  final bool isPlaying;
  final double animationValue;

  WaveformPainter({
    required this.waveformData,
    required this.isPlaying,
    required this.animationValue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..strokeWidth = 2;

    final centerY = size.height / 2;
    final barWidth = size.width / waveformData.length;

    // Draw background gradient
    final backgroundGradient = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.deepPurple.withOpacity(0.3),
        Colors.black87,
        Colors.deepPurple.withOpacity(0.3),
      ],
    );
    
    paint.shader = backgroundGradient.createShader(
      Rect.fromLTWH(0, 0, size.width, size.height),
    );
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paint);

    // Draw waveform bars
    for (int i = 0; i < waveformData.length; i++) {
      final barHeight = waveformData[i] * (size.height * 0.8);
      final x = i * barWidth;
      
      // Create gradient for each bar based on amplitude
      final barGradient = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          _getColorForAmplitude(waveformData[i]).withOpacity(0.8),
          _getColorForAmplitude(waveformData[i]),
          _getColorForAmplitude(waveformData[i]).withOpacity(0.8),
        ],
      );
      
      paint.shader = barGradient.createShader(
        Rect.fromLTWH(x, centerY - barHeight/2, barWidth - 1, barHeight),
      );
      
      // Add pulsing effect when playing
      double pulseEffect = isPlaying ? (1.0 + math.sin(animationValue * 2 * math.pi + i) * 0.1) : 1.0;
      final adjustedHeight = barHeight * pulseEffect;
      
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, centerY - adjustedHeight/2, barWidth - 1, adjustedHeight),
          const Radius.circular(2),
        ),
        paint,
      );
    }

    // Draw center line
    paint.shader = null;
    paint.color = Colors.white.withOpacity(0.3);
    paint.strokeWidth = 1;
    canvas.drawLine(
      Offset(0, centerY),
      Offset(size.width, centerY),
      paint,
    );
  }

  Color _getColorForAmplitude(double amplitude) {
    if (amplitude < 0.2) return Colors.green;
    if (amplitude < 0.4) return Colors.yellow;
    if (amplitude < 0.7) return Colors.orange;
    return Colors.red;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

