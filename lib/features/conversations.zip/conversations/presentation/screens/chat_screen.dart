import 'dart:async';
import 'dart:math';

// import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sagr/core/services/voice_recorder_service.dart';
import 'package:sagr/features/conversations/data/models/message_model.dart';
import 'package:sagr/features/conversations/presentation/controllers/chat_controller.dart';
import 'package:sagr/features/conversations/presentation/screens/vv.dart';
import 'package:sagr/features/conversations/presentation/widgets/whatsapp_audio.dart';
import 'package:uuid/uuid.dart';

import 'package:just_audio/just_audio.dart';

import '../controllers/scroll_controller.dart';
import '../widgets/audio.dart';

class ChatScreen extends StatefulWidget {
  final User? conversationUser;

  const ChatScreen({
    Key? key,
    this.conversationUser,
  }) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final _chatController = Get.put(ConversationChatController(Get.find()));
  final ScrollController scrollController = ScrollController();
  final ScrollControllerX controller = Get.put(ScrollControllerX());

  VoiceRecorderService voiceRecorder = VoiceRecorderService();
  // final AudioPlayer _audioPlayer = AudioPlayer();
    List<double> _waveData = List.generate(100, (_) => 0.1);
  Timer? _waveTimer;
  final Random _random = Random();

    double _waveHeight = 12.0;
  Color _waveColor = Colors.blue;



  bool _isRecording = false;
  int _recordDuration = 0;
  Timer? _recordingTimer;
  bool _showEmojiPicker = false;
  List<Message> _messages = [];
  bool _isPlaying = false;
  final User _currentUser = User(
    id: "1",
    name: "Me",
    avatarUrl: "https://i.pravatar.cc/150?img=1",
    isOnline: true,
  );

  late User _otherUser;

  @override
  void initState() {
    super.initState();
    _otherUser = widget.conversationUser ??
        User(
          id: "2",
          name: "Alex Smith",
          avatarUrl: "https://i.pravatar.cc/150?img=2",
          isOnline: true,
        );
    // _loadMessages();
// _setupAudioPlayerListeners();
_requestPermissions();
    _scrollToBottom();



    // _chatController.scrollToBottom();
  }

 



   Future<void> _requestPermissions() async {
    await Permission.storage.request();
  }

  //   void _setupAudioPlayerListeners() {
  //   _audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
  //     setState(() {
  //       _isPlaying = state == PlayerState.playing;
  //     });
      
  //     if (state == PlayerState.playing) {
  //       _startWaveSimulation();
  //     } else {
  //       _stopWaveSimulation();
  //     }
  //   });

  //   _audioPlayer.onPositionChanged.listen((Duration position) {
  //     // Position update could be used to sync wave with actual audio playback
  //   });
    
  //   _audioPlayer.onPlayerComplete.listen((_) {
  //     setState(() {
  //       _isPlaying = false;
  //       _stopWaveSimulation();
  //       _resetWaveData();
  //     });
  //   });
  // }


void _resetWaveData() {
    setState(() {
      _waveData = List.generate(100, (_) => 0.1);
    });
  }
  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    _recordingTimer?.cancel();
    super.dispose();
  }

  void _sendMessage() {
    if (_textController.text.trim().isEmpty) return;

    _chatController.sendTextMessage(context, _textController.text);
          setState(() {
            _textController.text = '';
          });

          _scrollToBottom();
  }

  void _startRecording() async {
    await voiceRecorder.startRecording();

    setState(() {
      _isRecording = true;
      _recordDuration = 0;
    });

    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _recordDuration++;
      });
    });
  }

  void _stopRecording() async {
    _recordingTimer?.cancel();

    final voicePath = await voiceRecorder.stopRecording();

    _chatController.sendVoiceMessage(context, voicePath!.path);

    setState(() {
      _isRecording = false;

      _messages.add(
        Message(
          text: "Voice message",
          isMe: true,
          timestamp: DateTime.now(),
          type: MessageType.voice,
          status: MessageStatus.sent,
          voiceDuration: _recordDuration,
        ),
      );
    });

    _scrollToBottom();
  }


  String? _localFilePath;
  String? _externalFileUrl;
    bool _isLocalFile = false;

Future<void> _playAudio(path) async {
    if (_isLocalFile && _localFilePath != null) {
      // await _audioPlayer.play(DeviceFileSource(_localFilePath!));
    } else if (!_isLocalFile && _externalFileUrl != null) {
      // await _audioPlayer.play(UrlSource(path!));
    }
  }



void _startWaveSimulation() {
    // Cancel any existing timer
    _waveTimer?.cancel();
    
    // Start a timer that updates the wave data
    _waveTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      setState(() {
        // Shift the wave data to the left
        for (int i = 0; i < _waveData.length - 1; i++) {
          _waveData[i] = _waveData[i + 1];
        }
        
        // Add a new value at the end
        _waveData[_waveData.length - 1] = 0.1 + _random.nextDouble() * 0.8;
      });
    });
  }

  void _stopWaveSimulation() {
    _waveTimer?.cancel();
    _waveTimer = null;
  }


  void _playTrack(path) async {

final player = AudioPlayer();

try {



print("PATH HERE: 🔥🔥🔥${path}");
  await player.stop();
    await player.setUrl(path);  // مثال: https://example.com/uploads/voice.m4a
    await player.play();
    _startWaveSimulation();
    player.playerStateStream.listen((state) {
    if (state.processingState == ProcessingState.completed) {
      print("🎉 الصوت خلص!");

      _stopWaveSimulation();
      // هنا تقدر تنفذ أي أكشن (تغيير أيقونة - إيقاف تايمر - إخفاء موجة صوتية)
    }
  });
    
  } catch (e) {
    print("Error playing audio: $e");
  }

// final player = AudioPlayer();


    //  await _audioPlayer.play(UrlSource("https://file-examples.com/storage/fe0707c5116828d4b9ad356/2017/11/file_example_MP3_700KB.mp3"), mode: PlayerMode.lowLatency);

  }

  void _toggleEmojiPicker() {
    setState(() {
      _showEmojiPicker = !_showEmojiPicker;
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent - 100,
          duration: const Duration(milliseconds: 100),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();

    if (date.day == now.day &&
        date.month == now.month &&
        date.year == now.year) {
      return "Today";
    } else if (date.day == now.day - 1 &&
        date.month == now.month &&
        date.year == now.year) {
      return "Yesterday";
    } else {
      return DateFormat('MMM d').format(date);
    }
  }

  Widget _buildDateSeparator(DateTime date) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Row(
        children: [
          Expanded(
            child: Divider(
              color: Colors.grey[400],
              thickness: 0.5,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              _formatDate(date),
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Divider(
              color: Colors.grey[400],
              thickness: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageStatus(MessageStatus status) {
    IconData iconData;
    Color iconColor;

    switch (status) {
      case MessageStatus.sent:
        iconData = Icons.check;
        iconColor = Colors.grey;
        break;
      case MessageStatus.delivered:
        iconData = Icons.done_all;
        iconColor = Colors.grey;
        break;
      case MessageStatus.read:
        iconData = Icons.done_all;
        iconColor = Colors.blue;
        break;
    }

    return Icon(
      iconData,
      size: 14,
      color: iconColor,
    );
  }

  Widget _buildTextMessage(MessageModel message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: message.getCurrentUserId() == message.userId
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: message.getCurrentUserId() == message.userId
                  ? Colors.blue[600]
                  : Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey[800]
                      : Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Text(
              message.text!,
              style: TextStyle(
                color: message.getCurrentUserId() == message.userId
                    ? Colors.white
                    : null,
                fontSize: 16,
              ),
            ),
          ),
         
          // if (message.reactions.isNotEmpty)
          //   _buildReactions(message),
          const SizedBox(height: 2),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                DateFormat('h:mm a').format(message.createdAt!),
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
              ),
              if (message.getCurrentUserId() == message.userId)
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  // child: _buildMessageStatus(message),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVoiceMessage(MessageModel message) {


    return  InkWell(
            // onTap: () => Get.to( () => WhatsAppVoicePlayer(audioUrl:  message.voicePath!,)),

              // _playTrack(message.voicePath),
// Navigator.push(context,
//               MaterialPageRoute(builder: (context) => VoiceWaveVisualizerPage()))

            
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Column(
          crossAxisAlignment: message.getCurrentUserId() == message.userId
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          children: [
             !_chatController.isLoading ? WhatsAppVoicePlayer(audioUrl:  message.voicePath!, isOutgoing: message.getCurrentUserId() == message.userId,) : Container(),
            // Container(
            //   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            //   decoration: BoxDecoration(
            //     color: message.getCurrentUserId() == message.userId
            //         ? Colors.blue[600]
            //         : Theme.of(context).brightness == Brightness.dark
            //             ? Colors.grey[800]
            //             : Colors.white,
            //     borderRadius: BorderRadius.circular(18),
            //   ),
            //   child: Row(
            //     mainAxisSize: MainAxisSize.min,
            //     children: [
            //       // Icon(
            //       //   Icons.play_arrow,
            //       //   color: message.getCurrentUserId() == message.userId
            //       //       ? Colors.white
            //       //       : Colors.blue,
            //       //   size: 24,
            //       // ),
            //       // const SizedBox(width: 8),
            //       // Container(
            //       //   width: 100,
            //       //   height: 24,
            //       //   decoration: BoxDecoration(
            //       //     color: message.getCurrentUserId() == message.userId
            //       //         ? Colors.blue[400]
            //       //         : Colors.grey[300],
            //       //     borderRadius: BorderRadius.circular(12),
            //       //   ),
            //       //   child: ClipRRect(
            //       //     borderRadius: BorderRadius.circular(12),
            //       //     child: CustomPaint(
            //       //       size: Size(MediaQuery.of(context).size.width, 200),
            //       //       painter: WaveformPainter(
            //       //         waveData: _waveData,
            //       //         color: _waveColor,
            //       //         waveHeight: _waveHeight,
            //       //       ),
            //       //     ),
            //       //     // child: CustomPaint(
            //       //     //   painter: WaveformPainter(
            //       //     //     color: message.getCurrentUserId() == message.userId
            //       //     //         ? Colors.white.withOpacity(0.5)
            //       //     //         : Colors.blue.withOpacity(0.5),
            //       //     //   ),
            //       //     // ),
            //       //   ),
            //       // ),
            //       const SizedBox(width: 8),

             
              
            //       // Text(
            //       //   _formatDuration(message.voiceDuration!),
            //       //   style: TextStyle(
            //       //     color: message.getCurrentUserId() == message.userId ? Colors.white : null,
            //       //     fontSize: 14,
            //       //   ),
            //       // ),
            //     ],
            //   ),
            // ),
            // if (message.reactions.isNotEmpty)
            //   _buildReactions(message),
            const SizedBox(height: 2),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Text(
                //   DateFormat('h:mm a').format(message.timestamp),
                //   style: TextStyle(
                //     color: Colors.grey[600],
                //     fontSize: 12,
                //   ),
                // ),
                // if (message.getCurrentUserId() == message.userId)
                // Padding(
                //   padding: const EdgeInsets.only(left: 4),
                //   child: _buildMessageStatus(message.status),
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFileMessage(Message message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        crossAxisAlignment:
            message.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: message.isMe
                  ? Colors.blue[600]
                  : Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey[800]
                      : Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.insert_drive_file,
                  color: message.isMe ? Colors.white : Colors.blue,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  message.text,
                  style: TextStyle(
                    color: message.isMe ? Colors.white : null,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
          if (message.reactions.isNotEmpty) _buildReactions(message),
          const SizedBox(height: 2),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                DateFormat('h:mm a').format(message.timestamp),
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
              ),
              if (message.isMe)
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: _buildMessageStatus(message.status),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildReactions(Message message) {
    return Container(
      margin: EdgeInsets.only(
        top: 4,
        right: message.isMe ? 8 : 0,
        left: message.isMe ? 0 : 8,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.grey[800]
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 2,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: message.reactions.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: Row(
              children: [
                Text(
                  entry.key,
                  style: const TextStyle(fontSize: 14),
                ),
                const SizedBox(width: 2),
                Text(
                  entry.value.toString(),
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  String _formatDuration(int seconds) {
    final minutes = (seconds / 60).floor();
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.grey[900]
            : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            IconButton(
              icon: Icon(
                _showEmojiPicker
                    ? Icons.keyboard
                    : Icons.emoji_emotions_outlined,
                color: Colors.grey[600],
              ),
              onPressed: _toggleEmojiPicker,
            ),
            IconButton(
              icon: Icon(
                Icons.attach_file,
                color: Colors.grey[600],
              ),
              onPressed: () {
                // Show attachment options
              },
            ),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey[800]
                      : Colors.grey[100],
                  borderRadius: BorderRadius.circular(24),
                ),
                child: _isRecording
                    ? Row(
                        children: [
                          Icon(
                            Icons.mic,
                            color: Colors.red,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _formatDuration(_recordDuration),
                            style: const TextStyle(fontSize: 16),
                          ),
                          const SizedBox(width: 8),
                          // Expanded(
                          //   child: CustomPaint(
                          //     painter: WaveformPainter(
                          //       color: Colors.red.withOpacity(0.5),
                          //     ),
                          //     size: const Size(double.infinity, 24),
                          //   ),
                          // ),
                        ],
                      )
                    : TextField(
                        controller: _textController,
                        decoration: const InputDecoration(
                          hintText: "Message",
                          border: InputBorder.none,
                        ),
                        maxLines: null,
                        onChanged: (value) => setState(() {
                            _textController.text = value;

                        }),
                      ),
              ),
            ),
            const SizedBox(width: 8),

            // Obx( () {
            //   return GestureDetector(
            //     onTap:() => _chatController.sendTextMessage(context, 'akk'),
            //     child: Container(
            //       padding: const EdgeInsets.all(10),
            //       decoration: const BoxDecoration(
            //         color: Colors.blue,
            //         shape: BoxShape.circle,
            //       ),
            //       child: const Icon(
            //         Icons.send,
            //         color: Colors.white,
            //       ),
            //     ),
            //   );
            // }),
            // GestureDetector(
            //     onTap: _sendMessage,
            //     child: Container(
            //       padding: const EdgeInsets.all(10),
            //       decoration: const BoxDecoration(
            //         color: Colors.blue,
            //         shape: BoxShape.circle,
            //       ),
            //       child: const Icon(
            //         Icons.send,
            //         color: Colors.white,
            //       ),
            //     ),
            //   ),

            // Text(_textController.text),
            // Text(_isRecording.toString()),

          
            if (_textController.text.isEmpty && !_isRecording)
              InkWell(
                onLongPress: _startRecording,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.mic,
                    color: Colors.white,
                  ),
                ),
              )
            else if (_isRecording)
              InkWell(
                onTap: _stopRecording,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.stop,
                    color: Colors.white,
                  ),
                ),
              )
            else
              GestureDetector(
                onTap: _sendMessage,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.send,
                    color: Colors.white,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    DateTime? lastDisplayedDate;

    controller.initListener(scrollController);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: NetworkImage(_otherUser.avatarUrl),
                ),
                if (_otherUser.isOnline)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Theme.of(context).scaffoldBackgroundColor,
                          width: 2,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _otherUser.name,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    _otherUser.isOnline ? "Online" : "Offline",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.videocam),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.call),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        // mainAxisAlignment: MainAxisAlignment.start,
        // crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Obx(() {
          //   // return _chatController.isLoading ?  Center(child: CircularProgressIndicator(),) :
          //   // Expanded(
          //   //   child: ListView.builder(
          //   //     physics: AlwaysScrollableScrollPhysics(),
          //   //     itemCount: _chatController.messages.length,
          //   //     itemBuilder: (contex, index){
          //   //     return Column(
          //   //       children: [
          //   //         // Text(_chatController.messages[index].id.toString()),
          //   //         Text(_chatController.messages[index].text!),
          //   //        Text(_chatController.messages[index].userId!.toString()),
          
          //   //         // Text(_chatController.messages[index].sentBy!?? ""),
          //   //         // Text(_chatController.messages[index].user!.id.toString()),
          //   //         // Text(_chatController.messages[index].user!.name!),
          //   //           // Text(_chatController.messages[index].getSenderName()),
          //   //       ],
          //   //     );
          //   //   }),
          //   // );
          
          //   return ;
          // }),

        GetBuilder<ConversationChatController>(
          init: ConversationChatController(Get.find()),
          builder: (ConversationChatController controllerChat) {
            return  _chatController.isLoading
                ? Expanded(
                    child: Center(
                    child: CircularProgressIndicator(),
                  ))
                : Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom:8.0),
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: AlwaysScrollableScrollPhysics(),
                        controller: controllerChat.scrollController,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        itemCount: controllerChat.messages.length,
                        itemBuilder: (context, index) {
                          final message = controllerChat.messages[index];
                          final showDateSeparator = lastDisplayedDate == null ||
                              !_isSameDay(message.createdAt!, lastDisplayedDate!);
                                
                          if (showDateSeparator) {
                            lastDisplayedDate = message.createdAt!;
                            return Column(
                              children: [
                                _buildDateSeparator(message.createdAt!),
                                Container(
                                  margin: EdgeInsets.only(bottom: 0),
                                  child: Align(
                                    alignment:
                                        message.userId == message.getCurrentUserId()
                                            ? Alignment.centerRight
                                            : Alignment.centerLeft,
                                    child:  _buildMessageWidget(message),
                                  ),
                                ),
                              ],
                            );
                          }
                                
                          return Align(
                            alignment:
                                message.userId == message.getCurrentUserId()
                                    ? Alignment.centerRight
                                    : Alignment.centerLeft,
                            child: _buildMessageWidget(message),
                          );
                        },
                      ),
                    ),
                  );
          }),
  

      // _buildMessageInput(),
          if (_showEmojiPicker)
            Container(
              height: 250,
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.grey[900]
                  : Colors.grey[200],
              child: const Placeholder(), // Replace with actual emoji picker
            ),
        ],
      ),
      bottomNavigationBar: _buildMessageInput(),
    );
  }

  bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day == date2.day;
  }

  Widget _buildMessageWidget(MessageModel message) {
    //  return _buildTextMessage(message);
    switch (message.type) {
      case 'text':
        return _buildTextMessage(message);
      case 'voice':
        return _buildVoiceMessage(message);
      // case MessageType.file:
      //   return _buildFileMessage(message);
      default:
        return _buildTextMessage(message);
    }
  }
}

// class WaveformPainter extends CustomPainter {
//   final Color color;

//   WaveformPainter({required this.color});

//   @override
//   void paint(Canvas canvas, Size size) {
//     final paint = Paint()
//       ..color = color
//       ..strokeWidth = 2
//       ..strokeCap = StrokeCap.round;

//     final width = size.width;
//     final height = size.height;
//     final centerY = height / 2;

//     // Generate random waveform
//     final random = DateTime.now().millisecondsSinceEpoch;
//     final points = <double>[];
//     final numberOfBars = (width / 4).floor();

//     for (int i = 0; i < numberOfBars; i++) {
//       final seed = (random + i * 10) % 100;
//       final amplitude = (seed / 100) * (height / 2);
//       points.add(amplitude);
//     }

//     for (int i = 0; i < numberOfBars; i++) {
//       final x = i * 4.0;
//       final amplitude = points[i];

//       canvas.drawLine(
//         Offset(x, centerY - amplitude),
//         Offset(x, centerY + amplitude),
//         paint,
//       );
//     }
//   }

//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
// }

enum MessageType { text, voice, image, file }

enum MessageStatus { sent, delivered, read }

class Message {
  final String id;
  final String text;
  final bool isMe;
  final DateTime timestamp;
  final MessageType type;
  final MessageStatus status;
  final int? voiceDuration; // in seconds
  final String? fileUrl;
  final Map<String, int> reactions;

  Message({
    required this.text,
    required this.isMe,
    required this.timestamp,
    required this.type,
    required this.status,
    this.voiceDuration,
    this.fileUrl,
    Map<String, int>? reactions,
  })  : id = const Uuid().v4(),
        reactions = reactions ?? {};
}

class User {
  final String id;
  final String name;
  final String avatarUrl;
  final bool isOnline;

  User({
    required this.id,
    required this.name,
    required this.avatarUrl,
    this.isOnline = false,
  });
}

class WaveformPainter extends CustomPainter {
  final List<double> waveData;
  final Color color;
  final double waveHeight;
  
  WaveformPainter({
    required this.waveData,
    required this.color,
    required this.waveHeight,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
      
    final double width = size.width;
    final double height = size.height;
    final double centerY = height / 2;
    
    final Path path = Path();
    final double segmentWidth = width / (waveData.length - 1);
    
    // Begin the path at the first data point
    path.moveTo(0, centerY - (waveData[0] * waveHeight));
    
    // Top wave curve
    for (int i = 1; i < waveData.length; i++) {
      path.lineTo(
        i * segmentWidth, 
        centerY - (waveData[i] * waveHeight)
      );
    }
    
    // Bottom wave curve (mirror of top)
    for (int i = waveData.length - 1; i >= 0; i--) {
      path.lineTo(
        i * segmentWidth, 
        centerY + (waveData[i] * waveHeight)
      );
    }
    
    // Close the path to create a complete shape
    path.close();
    
    // Draw filled wave with lower opacity
    canvas.drawPath(
      path, 
      Paint()
        ..color = color.withOpacity(0.2)
        ..style = PaintingStyle.fill
    );
    
    // Draw wave outline
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}