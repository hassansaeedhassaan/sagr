import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';

class VoiceWaveVisualizerPage extends StatefulWidget {
  const VoiceWaveVisualizerPage({super.key});

  @override
  State<VoiceWaveVisualizerPage> createState() => _VoiceWaveVisualizerPageState();
}

class _VoiceWaveVisualizerPageState extends State<VoiceWaveVisualizerPage> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  String? _localFilePath;
  String? _externalFileUrl;
  bool _isPlaying = false;
  List<double> _waveData = List.generate(100, (_) => 0.2);
  Timer? _waveTimer;
  final Random _random = Random();
  
  bool _isLocalFile = true;
  double _waveHeight = 25.0;
  Color _waveColor = Colors.blue;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _setupAudioPlayerListeners();
  }

  Future<void> _requestPermissions() async {
    await Permission.storage.request();
  }

  void _setupAudioPlayerListeners() {
    _audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
      setState(() {
        _isPlaying = state == PlayerState.playing;
      });
      
      if (state == PlayerState.playing) {
        _startWaveSimulation();
      } else {
        _stopWaveSimulation();
      }
    });

    _audioPlayer.onPositionChanged.listen((Duration position) {
      // Position update could be used to sync wave with actual audio playback
    });
    
    _audioPlayer.onPlayerComplete.listen((_) {
      setState(() {
        _isPlaying = false;
        _stopWaveSimulation();
        _resetWaveData();
      });
    });
  }

  void _resetWaveData() {
    setState(() {
      _waveData = List.generate(100, (_) => 0.1);
    });
  }

  Future<void> _pickLocalFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
    );

    if (result != null) {
      setState(() {
        _localFilePath = result.files.single.path;
        _isLocalFile = true;
      });
      _stopAudio();
    }
  }

  Future<void> _pickExternalFile() async {
    // For demo purposes, let's use a text field to input URL
    TextEditingController urlController = TextEditingController();
    
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Enter Audio URL'),
        content: TextField(
          controller: urlController,
          decoration: const InputDecoration(
            hintText: 'https://example.com/audio.mp3',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (urlController.text.isNotEmpty) {
                setState(() {
                  _externalFileUrl = urlController.text;
                  _isLocalFile = false;
                });
                _stopAudio();
              }
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _playAudio() async {
    if (_isLocalFile && _localFilePath != null) {
      await _audioPlayer.play(DeviceFileSource(_localFilePath!));
    } else if (!_isLocalFile && _externalFileUrl != null) {
      await _audioPlayer.play(UrlSource(_externalFileUrl!));
    }
  }

  Future<void> _stopAudio() async {
    await _audioPlayer.stop();
  }

  Future<void> _pauseAudio() async {
    await _audioPlayer.pause();
  }

  void _startWaveSimulation() {
    // Cancel any existing timer
    _waveTimer?.cancel();
    
    // Start a timer that updates the wave data
    _waveTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      setState(() {
        // Shift the wave data to the left
        for (int i = 0; i < _waveData.length - 1; i++) {
          _waveData[i] = _waveData[i + 1];
        }
        
        // Add a new value at the end
        _waveData[_waveData.length - 1] = 0.1 + _random.nextDouble() * 0.8;
      });
    });
  }

  void _stopWaveSimulation() {
    _waveTimer?.cancel();
    _waveTimer = null;
  }

  void _changeWaveColor() {
    final List<Color> colors = [
      Colors.blue,
      Colors.red,
      Colors.green,
      Colors.purple,
      Colors.orange,
      Colors.teal,
    ];
    
    setState(() {
      _waveColor = colors[_random.nextInt(colors.length)];
    });
  }

  @override
  void dispose() {
    _waveTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Voice Wave Visualizer'),
        actions: [
          IconButton(
            icon: const Icon(Icons.color_lens),
            onPressed: _changeWaveColor,
            tooltip: 'Change Wave Color',
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Container(
                padding: const EdgeInsets.all(16),
                width: double.infinity,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // File source indicator
                    Text(
                      _isLocalFile 
                        ? 'Source: Local File${_localFilePath != null ? "\n${_localFilePath!.split('/').last}" : ""}'
                        : 'Source: External URL${_externalFileUrl != null ? "\n${_externalFileUrl!}" : ""}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 20),
                    
                    // Waveform display
                    SizedBox(
                      height: 200,
                      child: CustomPaint(
                        size: Size(MediaQuery.of(context).size.width, 200),
                        painter: WaveformPainter(
                          waveData: _waveData,
                          color: _waveColor,
                          waveHeight: _waveHeight,
                        ),
                      ),
                    ),
                    
                    // Wave height slider
                    Row(
                      children: [
                        const Text('Wave Height: '),
                        Expanded(
                          child: Slider(
                            value: _waveHeight,
                            min: 10,
                            max: 150,
                            onChanged: (value) {
                              setState(() {
                                _waveHeight = value;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          // Bottom control panel
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceVariant,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Source selection buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.folder_open),
                      label: const Text('Local File'),
                      onPressed: _pickLocalFile,
                    ),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.link),
                      label: const Text('External URL'),
                      onPressed: _pickExternalFile,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                
                // Playback controls
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.stop),
                      onPressed: (_isPlaying || _localFilePath != null || _externalFileUrl != null) 
                        ? _stopAudio 
                        : null,
                      iconSize: 40,
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
                      onPressed: (_localFilePath != null || _externalFileUrl != null) 
                        ? (_isPlaying ? _pauseAudio : _playAudio)
                        : null,
                      iconSize: 56,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class WaveformPainter extends CustomPainter {
  final List<double> waveData;
  final Color color;
  final double waveHeight;
  
  WaveformPainter({
    required this.waveData,
    required this.color,
    required this.waveHeight,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
      
    final double width = size.width;
    final double height = size.height;
    final double centerY = height / 2;
    
    final Path path = Path();
    final double segmentWidth = width / (waveData.length - 1);
    
    // Begin the path at the first data point
    path.moveTo(0, centerY - (waveData[0] * waveHeight));
    
    // Top wave curve
    for (int i = 1; i < waveData.length; i++) {
      path.lineTo(
        i * segmentWidth, 
        centerY - (waveData[i] * waveHeight)
      );
    }
    
    // Bottom wave curve (mirror of top)
    for (int i = waveData.length - 1; i >= 0; i--) {
      path.lineTo(
        i * segmentWidth, 
        centerY + (waveData[i] * waveHeight)
      );
    }
    
    // Close the path to create a complete shape
    path.close();
    
    // Draw filled wave with lower opacity
    canvas.drawPath(
      path, 
      Paint()
        ..color = color.withOpacity(0.2)
        ..style = PaintingStyle.fill
    );
    
    // Draw wave outline
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}