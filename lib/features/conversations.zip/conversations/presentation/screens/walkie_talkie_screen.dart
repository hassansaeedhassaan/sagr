import 'package:flutter/material.dart';

class WalkieTalkieScreen extends StatelessWidget {
  const WalkieTalkieScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Center(
        child: Text("DATTATATA"),
      ),
    );
  }
}