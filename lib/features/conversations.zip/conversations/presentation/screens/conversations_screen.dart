// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:shimmer/shimmer.dart';
// import 'dart:async';
// import '../../../../models/user.dart';

// class ConversationsScreen extends StatefulWidget {
//   const ConversationsScreen({Key? key}) : super(key: key);

//   @override
//   _ConversationsScreenState createState() => _ConversationsScreenState();
// }

// class _ConversationsScreenState extends State<ConversationsScreen> {
//   final List<Conversation> _conversations = [];
//   final TextEditingController _searchController = TextEditingController();
//   bool _isSearching = false;
//   List<Conversation> _filteredConversations = [];

//   @override
//   void initState() {
//     super.initState();
//     _loadConversations();
//     _filteredConversations = _conversations;
//     _searchController.addListener(_filterConversations);
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }

//   void _loadConversations() {
//     // Simulated conversations
//     setState(() {
//       _conversations.addAll([
//         Conversation(
//           id: "1",
//           user: User(
//             id: "2",
//             name: "Alex Smith",
//             avatarUrl: "https://i.pravatar.cc/150?img=2",
//             isOnline: true,
//           ),
//           lastMessage: "Here's the link: github.com/flutter-chat-ui",
//           lastMessageTime: DateTime.now().subtract(const Duration(minutes: 44)),
//           unread: false,
//         ),
//         Conversation(
//           id: "2",
//           user: User(
//             id: "3",
//             name: "Emma Johnson",
//             avatarUrl: "https://i.pravatar.cc/150?img=5",
//             isOnline: true,
//           ),
//           lastMessage: "Can you send me the design files?",
//           lastMessageTime: DateTime.now().subtract(const Duration(hours: 2)),
//           unread: true,
//           unreadCount: 1,
//         ),
//         Conversation(
//           id: "3",
//           user: User(
//             id: "4",
//             name: "Michael Chen",
//             avatarUrl: "https://i.pravatar.cc/150?img=8",
//             isOnline: false,
//           ),
//           lastMessage: "Voice message",
//           lastMessageTime: DateTime.now().subtract(const Duration(hours: 5)),
//           lastMessageType: MessageType.voice,
//           unread: true,
//           unreadCount: 3,
//         ),
//         Conversation(
//           id: "4",
//           user: User(
//             id: "5",
//             name: "Sophia Garcia",
//             avatarUrl: "https://i.pravatar.cc/150?img=9",
//             isOnline: false,
//           ),
//           lastMessage: "Let's meet tomorrow at 2 PM",
//           lastMessageTime: DateTime.now().subtract(const Duration(days: 1)),
//           unread: false,
//         ),
//         Conversation(
//           id: "5",
//           user: User(
//             id: "6",
//             name: "James Wilson",
//             avatarUrl: "https://i.pravatar.cc/150?img=11",
//             isOnline: true,
//           ),
//           lastMessage: "Project documentation.pdf",
//           lastMessageTime: DateTime.now().subtract(const Duration(days: 2)),
//           lastMessageType: MessageType.file,
//           unread: false,
//         ),
//         Conversation(
//           id: "6",
//           user: User(
//             id: "7",
//             name: "Design Team",
//             avatarUrl: "https://i.pravatar.cc/150?img=12",
//             isOnline: true,
//           ),
//           lastMessage: "I've updated the mockups",
//           lastMessageTime: DateTime.now().subtract(const Duration(days: 3)),
//           unread: false,
//         ),
//         Conversation(
//           id: "7",
//           user: User(
//             id: "8",
//             name: "Frontend Group",
//             avatarUrl: "https://i.pravatar.cc/150?img=15",
//             isOnline: false,
//           ),
//           lastMessage: "We need to fix that bug in production",
//           lastMessageTime: DateTime.now().subtract(const Duration(days: 4)),
//           unread: false,
//         ),
//         Conversation(
//           id: "8",
//           user: User(
//             id: "9",
//             name: "Lisa Thompson",
//             avatarUrl: "https://i.pravatar.cc/150?img=18",
//             isOnline: true,
//           ),
//           lastMessage: "Did you see the news?",
//           lastMessageTime: DateTime.now().subtract(const Duration(days: 6)),
//           unread: false,
//         ),
//       ]);
//     });
//   }

//   void _toggleSearch() {
//     setState(() {
//       _isSearching = !_isSearching;
//       if (!_isSearching) {
//         _searchController.clear();
//         _filteredConversations = _conversations;
//       }
//     });
//   }

//   void _filterConversations() {
//     if (_searchController.text.isEmpty) {
//       setState(() {
//         _filteredConversations = _conversations;
//       });
//       return;
//     }

//     final query = _searchController.text.toLowerCase();
//     setState(() {
//       _filteredConversations = _conversations.where((conversation) {
//         return conversation.user.name.toLowerCase().contains(query) ||
//                conversation.lastMessage.toLowerCase().contains(query);
//       }).toList();
//     });
//   }

//   String _formatConversationTimestamp(DateTime timestamp) {
//     final now = DateTime.now();
//     final difference = now.difference(timestamp);
    
//     if (difference.inDays == 0) {
//       return DateFormat('h:mm a').format(timestamp);
//     } else if (difference.inDays < 7) {
//       return DateFormat('E').format(timestamp); // Day name (e.g., Mon, Tue)
//     } else {
//       return DateFormat('MM/dd/yy').format(timestamp);
//     }
//   }

//   Widget _buildConversationItem(Conversation conversation) {
//     final theme = Theme.of(context);
//     final isDarkMode = theme.brightness == Brightness.dark;
    
//     return InkWell(
//       onTap: () {
//         // Navigator.push(
//         //   context,
//         //   MaterialPageRoute(
//         //     builder: (context) => ChatScreen(conversationUser: conversation.user),
//         //   ),
//         // );
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//         child: Row(
//           children: [
//             Stack(
//               children: [

                
//                 CircleAvatar(
//                   radius: 28,
//                   backgroundImage: NetworkImage(conversation.user.avatarUrl),
//                 ),
//                 if (conversation.user.isOnline)
//                   Positioned(
//                     right: 0,
//                     bottom: 0,
//                     child: Container(
//                       width: 14,
//                       height: 14,
//                       decoration: BoxDecoration(
//                         color: Colors.green,
//                         shape: BoxShape.circle,
//                         border: Border.all(
//                           color: isDarkMode ? Colors.grey[900]! : Colors.white,
//                           width: 2,
//                         ),
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//             const SizedBox(width: 12),
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Text(
//                         conversation.user.name,
//                         style: TextStyle(
//                           fontSize: 16,
//                           fontWeight: conversation.unread ? FontWeight.bold : FontWeight.normal,
//                         ),
//                       ),
//                       Text(
//                         _formatConversationTimestamp(conversation.lastMessageTime),
//                         style: TextStyle(
//                           fontSize: 12,
//                           color: conversation.unread 
//                             ? Colors.blue
//                             : isDarkMode ? Colors.grey[400] : Colors.grey[600],
//                           fontWeight: conversation.unread ? FontWeight.bold : FontWeight.normal,
//                         ),
//                       ),
//                     ],
//                   ),
//                   const SizedBox(height: 4),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Expanded(
//                         child: Row(
//                           children: [
//                             if (conversation.lastMessageType == MessageType.voice)
//                               Padding(
//                                 padding: const EdgeInsets.only(right: 4),
//                                 child: Icon(
//                                   Icons.mic,
//                                   size: 16,
//                                   color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
//                                 ),
//                               )
//                             else if (conversation.lastMessageType == MessageType.file)
//                               Padding(
//                                 padding: const EdgeInsets.only(right: 4),
//                                 child: Icon(
//                                   Icons.insert_drive_file,
//                                   size: 16,
//                                   color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
//                                 ),
//                               ),
//                             Expanded(
//                               child: Text(
//                                 conversation.lastMessage,
//                                 maxLines: 1,
//                                 overflow: TextOverflow.ellipsis,
//                                 style: TextStyle(
//                                   fontSize: 14,
//                                   color: conversation.unread
//                                     ? isDarkMode ? Colors.white : Colors.black
//                                     : isDarkMode ? Colors.grey[400] : Colors.grey[600],
//                                   fontWeight: conversation.unread ? FontWeight.bold : FontWeight.normal,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       if (conversation.unreadCount > 0)
//                         Container(
//                           padding: const EdgeInsets.all(6),
//                           decoration: const BoxDecoration(
//                             color: Colors.blue,
//                             shape: BoxShape.circle,
//                           ),
//                           child: Text(
//                             conversation.unreadCount.toString(),
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 12,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: _isSearching
//           ? TextField(
//               controller: _searchController,
//               decoration: const InputDecoration(
//                 hintText: "Search conversations...",
//                 border: InputBorder.none,
//               ),
//               autofocus: true,
//             )
//           : const Text('Messages'),
//         actions: [
//           IconButton(
//             icon: Icon(_isSearching ? Icons.close : Icons.search),
//             onPressed: _toggleSearch,
//           ),
//           IconButton(
//             icon: const Icon(Icons.more_vert),
//             onPressed: () {},
//           ),
//         ],
//       ),
//       body: _filteredConversations.isEmpty
//           ? Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(
//                     Icons.search_off,
//                     size: 64,
//                     color: Colors.grey[400],
//                   ),
//                   const SizedBox(height: 16),
//                   Text(
//                     _isSearching
//                         ? "No conversations found"
//                         : "No conversations yet",
//                     style: TextStyle(
//                       fontSize: 16,
//                       color: Colors.grey[600],
//                     ),
//                   ),
//                 ],
//               ),
//             )
//           : ListView.separated(
//               itemCount: _filteredConversations.length,
//               separatorBuilder: (context, index) => Divider(
//                 color: Colors.grey[300],
//                 height: 1,
//                 indent: 76,
//               ),
//               itemBuilder: (context, index) {
//                 return _buildConversationItem(_filteredConversations[index]);
//               },
//             ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           // Open new conversation screen
//         },
//         child: const Icon(Icons.chat),
//       ),
//     );
//   }
// }


// Widget _buildShimmerItem() {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//       child: Row(
//         children: [
//           // Avatar shimmer
//           Shimmer.fromColors(
//             baseColor: Colors.grey[300]!,
//             highlightColor: Colors.grey[100]!,
//             child: Container(
//               width: 56,
//               height: 56,
//               decoration: const BoxDecoration(
//                 color: Colors.white,
//                 shape: BoxShape.circle,
//               ),
//             ),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     // Name shimmer
//                     Shimmer.fromColors(
//                       baseColor: Colors.grey[300]!,
//                       highlightColor: Colors.grey[100]!,
//                       child: Container(
//                         width: 120,
//                         height: 16,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(2),
//                         ),
//                       ),
//                     ),
//                     // Time shimmer
//                     Shimmer.fromColors(
//                       baseColor: Colors.grey[300]!,
//                       highlightColor: Colors.grey[100]!,
//                       child: Container(
//                         width: 40,
//                         height: 12,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(2),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 8),
//                 // Message shimmer
//                 Shimmer.fromColors(
//                   baseColor: Colors.grey[300]!,
//                   highlightColor: Colors.grey[100]!,
//                   child: Container(
//                     width: double.infinity,
//                     height: 14,
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(2),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
  



import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sagr/features/conversations/data/models/conversation_model.dart';
import 'package:shimmer/shimmer.dart';
import 'dart:async';
import '../../../../models/user.dart';
import '../../../auth/presentation/screens/chat_screen.dart';
import '../controllers/conversations_controller.dart';

 enum MessageType { text, voice, image, file }
class User {
  final String id;
  final String name;
  final String avatarUrl;
  final bool isOnline;

  User({
    required this.id,
    required this.name,
    required this.avatarUrl,
    this.isOnline = false,
  });
}

class Conversation {
  final String id;
  final User user;
  final String lastMessage;
  final DateTime lastMessageTime;
  final bool unread;
  final int unreadCount;
  final MessageType lastMessageType;

  Conversation({
    required this.id,
    required this.user,
    required this.lastMessage,
    required this.lastMessageTime,
    this.unread = false,
    this.unreadCount = 0,
    this.lastMessageType = MessageType.text,
  });
}





class ConversationsScreen extends StatefulWidget {
  const ConversationsScreen({Key? key}) : super(key: key);

  @override
  _ConversationsScreenState createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends State<ConversationsScreen> {
  final List<Conversation> _conversations = [];
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;
  List<Conversation> _filteredConversations = [];
  bool _isLoading = false; // Add loading state

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_filterConversations);
    
    // Simulate network delay when loading conversations
    Timer(const Duration(seconds: 2), () {
      _loadConversations();
      setState(() {
        _isLoading = false;
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _loadConversations() {
    // Simulated conversations
    setState(() {
      _conversations.addAll([
        Conversation(
          id: "1",
          user: User(
            id: "2",
            name: "Alex Smith",
            avatarUrl: "https://i.pravatar.cc/150?img=2",
            isOnline: true,
          ),
          lastMessage: "Here's the link: github.com/flutter-chat-ui",
          lastMessageTime: DateTime.now().subtract(const Duration(minutes: 44)),
          unread: false,
        ),
        Conversation(
          id: "2",
          user: User(
            id: "3",
            name: "Emma Johnson",
            avatarUrl: "https://i.pravatar.cc/150?img=5",
            isOnline: true,
          ),
          lastMessage: "Can you send me the design files?",
          lastMessageTime: DateTime.now().subtract(const Duration(hours: 2)),
          unread: true,
          unreadCount: 1,
        ),
        Conversation(
          id: "3",
          user: User(
            id: "4",
            name: "Michael Chen",
            avatarUrl: "https://i.pravatar.cc/150?img=8",
            isOnline: false,
          ),
          lastMessage: "Voice message",
          lastMessageTime: DateTime.now().subtract(const Duration(hours: 5)),
          lastMessageType: MessageType.voice,
          unread: true,
          unreadCount: 3,
        ),
        Conversation(
          id: "4",
          user: User(
            id: "5",
            name: "Sophia Garcia",
            avatarUrl: "https://i.pravatar.cc/150?img=9",
            isOnline: false,
          ),
          lastMessage: "Let's meet tomorrow at 2 PM",
          lastMessageTime: DateTime.now().subtract(const Duration(days: 1)),
          unread: false,
        ),
        Conversation(
          id: "5",
          user: User(
            id: "6",
            name: "James Wilson",
            avatarUrl: "https://i.pravatar.cc/150?img=11",
            isOnline: true,
          ),
          lastMessage: "Project documentation.pdf",
          lastMessageTime: DateTime.now().subtract(const Duration(days: 2)),
          lastMessageType: MessageType.file,
          unread: false,
        ),
        Conversation(
          id: "6",
          user: User(
            id: "7",
            name: "Design Team",
            avatarUrl: "https://i.pravatar.cc/150?img=12",
            isOnline: true,
          ),
          lastMessage: "I've updated the mockups",
          lastMessageTime: DateTime.now().subtract(const Duration(days: 3)),
          unread: false,
        ),
        Conversation(
          id: "7",
          user: User(
            id: "8",
            name: "Frontend Group",
            avatarUrl: "https://i.pravatar.cc/150?img=15",
            isOnline: false,
          ),
          lastMessage: "We need to fix that bug in production",
          lastMessageTime: DateTime.now().subtract(const Duration(days: 4)),
          unread: false,
        ),
        Conversation(
          id: "8",
          user: User(
            id: "9",
            name: "Lisa Thompson",
            avatarUrl: "https://i.pravatar.cc/150?img=18",
            isOnline: true,
          ),
          lastMessage: "Did you see the news?",
          lastMessageTime: DateTime.now().subtract(const Duration(days: 6)),
          unread: false,
        ),
      ]);
      _filteredConversations = _conversations;
    });
  }

  void _toggleSearch() {
    setState(() {
      _isSearching = !_isSearching;
      if (!_isSearching) {
        _searchController.clear();
        _filteredConversations = _conversations;
      }
    });
  }

  void _filterConversations() {
    if (_searchController.text.isEmpty) {
      setState(() {
        _filteredConversations = _conversations;
      });
      return;
    }

    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredConversations = _conversations.where((conversation) {
        return conversation.user.name.toLowerCase().contains(query) ||
               conversation.lastMessage.toLowerCase().contains(query);
      }).toList();
    });
  }

  String _formatConversationTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);
    
    if (difference.inDays == 0) {
      return DateFormat('hh:mm a').format(timestamp);
    } else if (difference.inDays < 7) {
      return DateFormat('E').format(timestamp); // Day name (e.g., Mon, Tue)
    } else {
      return DateFormat('MM/dd/yy').format(timestamp);
    }
  }

  Widget _buildConversationItem(ConversationModel conversation) {
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;
    
    return InkWell(
      onTap: ()  => Get.toNamed('/chat', arguments: conversation.id) ,
        
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (context) => ChatScreen(),
        //   ),
        // );
      // },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundImage: NetworkImage("https://upload.wikimedia.org/wikipedia/commons/9/93/Amateur-made_Na%27vi.jpg"),
                ),
                // if (conversation.user.isOnline)
                if (true)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isDarkMode ? Colors.grey[900]! : Colors.white,
                          width: 2,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        conversation.getDisplayName(),
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: true ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                      Text(
                        _formatConversationTimestamp(conversation.lastMessage!.createdAt!),

                        // _formatConversationTimestamp(DateTime.now().subtract(const Duration(days: 3))),
                        style: TextStyle(
                          fontSize: 12,
                          color: true
                            ? Colors.blue
                            : isDarkMode ? Colors.grey[400] : Colors.grey[600],
                          fontWeight: true ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            if ('voice' == MessageType.voice)
                              Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Icon(
                                  Icons.mic,
                                  size: 16,
                                  color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
                                ),
                              )
                            else if ('file' == MessageType.file)
                              Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Icon(
                                  Icons.insert_drive_file,
                                  size: 16,
                                  color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
                                ),
                              ),
                            Expanded(
                              child: Text(
                                conversation.lastMessage!.text.toString(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: false
                                    ? isDarkMode ? Colors.white : Colors.black
                                    : isDarkMode ? Color.fromARGB(255, 21, 18, 18) : Colors.grey[600],
                                  fontWeight: true ? FontWeight.bold : FontWeight.normal,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      if (conversation.unreadCount! > 0)
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: Colors.blue,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            conversation.unreadCount.toString(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Shimmer loading effect for conversation items
  Widget _buildShimmerItem() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          // Avatar shimmer
          Shimmer.fromColors(
            baseColor: Colors.grey[300]!,
            highlightColor: Colors.grey[100]!,
            child: Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Name shimmer
                    Shimmer.fromColors(
                      baseColor: Colors.grey[300]!,
                      highlightColor: Colors.grey[100]!,
                      child: Container(
                        width: 120,
                        height: 16,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    // Time shimmer
                    Shimmer.fromColors(
                      baseColor: Colors.grey[300]!,
                      highlightColor: Colors.grey[100]!,
                      child: Container(
                        width: 40,
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Message shimmer
                Shimmer.fromColors(
                  baseColor: Colors.grey[300]!,
                  highlightColor: Colors.grey[100]!,
                  child: Container(
                    width: double.infinity,
                    height: 14,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _isSearching
          ? TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: "Search conversations...",
                border: InputBorder.none,
              ),
              autofocus: true,
            )
          : const Text('Messages'),
        actions: [
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search),
            onPressed: _toggleSearch,
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {},
          ),
        ],
      ),
      body:  !_isLoading 
          // Show shimmer loading effect while loading
          ? 
          Container(
            child: GetBuilder<ConversationsController>(
              init: ConversationsController(Get.find()),
              builder: (ConversationsController conversationsController){
              return conversationsController.isLoading? ListView.separated(
              itemCount: 8, // Number of shimmer items to display
              separatorBuilder: (context, index) => Divider(
                color: Colors.grey[300],
                height: 1,
                indent: 76,
              ),
              itemBuilder: (context, index) => _buildShimmerItem(),
            ): Container(

                child:  ListView.separated(
                  itemCount: conversationsController.events.length,
                  separatorBuilder: (context, index) => Divider(
                    color: Colors.grey[300],
                    height: 1,
                    indent: 76,
                  ),
                  itemBuilder: (context, index) {
                    return _buildConversationItem(conversationsController.events.elementAt(index));
                  },
                ),
                // child: ListView.builder(
                //   physics: AlwaysScrollableScrollPhysics(),
                //   itemCount: conversationsController.events.length,
                //   itemBuilder: (context, index){

                //     return Container(
                //       child:Text(conversationsController.events.elementAt(index).id.toString()),
                //     );
                // }),
              );
            }),
          )
          
          : _filteredConversations.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.search_off,
                        size: 64,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _isSearching
                            ? "No conversations found"
                            : "No conversations yet",
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  itemCount: _filteredConversations.length,
                  separatorBuilder: (context, index) => Divider(
                    color: Colors.grey[300],
                    height: 1,
                    indent: 76,
                  ),
                  itemBuilder: (context, index) {
                    // return _buildConversationItem();
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Open new conversation screen
        },
        child: const Icon(Icons.chat),
      ),
    );
  }
}