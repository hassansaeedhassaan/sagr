import 'dart:async';

import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class ScrollControllerX extends GetxController {
  // Observable properties
  final RxDouble scrollPosition = 0.0.obs;
  final RxBool isScrolling = false.obs;
  final RxString scrollDirection = "".obs;
  final RxBool isAtTop = true.obs;
  final RxBool isAtBottom = false.obs;
  
  // Scroll controller reference
  ScrollController? _scrollController;
  
  // Timer to detect when scrolling stops
  Timer? _scrollingTimer;

  @override
  void onClose() {
    _scrollController?.removeListener(_scrollListener);
    _scrollController?.dispose();
    _scrollingTimer?.cancel();
    super.onClose();
  }

  void initListener(ScrollController controller) {
    if (_scrollController != controller) {
      _scrollController?.removeListener(_scrollListener);
      _scrollController = controller;
      _scrollController!.addListener(_scrollListener);
    }
  }

  void _scrollListener() {
    if (_scrollController == null) return;
    
    // Update the scroll position
    scrollPosition.value = _scrollController!.position.pixels;
    
    // Update top/bottom status
    isAtTop.value = _scrollController!.position.pixels <= 0;
    isAtBottom.value = _scrollController!.position.pixels >= 
        _scrollController!.position.maxScrollExtent;
    
    // Update scroll direction
    if (_scrollController!.position.userScrollDirection == ScrollDirection.forward) {
      scrollDirection.value = "Up";
    } else if (_scrollController!.position.userScrollDirection == ScrollDirection.reverse) {
      scrollDirection.value = "Down";
    }
    
    // Handle scrolling state with debounce
    isScrolling.value = true;
    _scrollingTimer?.cancel();
    _scrollingTimer = Timer(Duration(milliseconds: 100), () {
      isScrolling.value = false;
    });
  }

  void scrollToTop() {
    if (_scrollController == null) return;
    _scrollController!.animateTo(
      0,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }

  void scrollToBottom() {
    if (_scrollController == null) return;
    _scrollController!.animateTo(
      _scrollController!.position.maxScrollExtent,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }
}