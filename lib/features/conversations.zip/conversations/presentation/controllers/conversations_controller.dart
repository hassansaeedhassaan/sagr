import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:sagr/features/conversations/data/models/message_model.dart';
import 'package:sagr/features/conversations/domain/entities/conversation.dart';
import 'package:sagr/models/user_model.dart';
import '../../../../models/pagination_filter.dart';
import '../../data/models/conversation_model.dart';
import '../../data/models/event_model.dart';
import '../../domain/usecases/get_conversations.dart';

class ConversationsController extends GetxController {
  // MaritalStatusUsecase instance
  final ConversationsUsecase conversationsUsecase;

  // MaritalStatusController Constructor
  ConversationsController(this.conversationsUsecase);

  RefreshController refreshController =
      RefreshController(initialRefresh: false);

  EventModel? event;

  // Rx Filters  Setter
  final RxBool _isLoading = true.obs;

  final _items = <ConversationModel>[].obs;

  List<ConversationModel> get events => _items.toList();
  
  final ScrollController scrollController =
      ScrollController(); // ScrollController

  // Rx Filters  Getter
  bool get isLoading => _isLoading.value;



  /// Rx Filters  Setter
  final _paginationFilter = PaginationFilter().obs;
  final RxBool _lastPage = false.obs;
  final RxBool _hasMore = true.obs;

  /// Rx Filters  Getter
  int get limit => _paginationFilter.value.limit;
  int get page => _paginationFilter.value.page;
  bool get lastPage => _lastPage.value;
  bool get hasMore => _hasMore.value;

  @override
  void onInit() {
    super.onInit();

    ever(_paginationFilter, (_) => _findItems());
    _changePaginationFilter(1, 5);
    //  scrollController.addListener(_scrollListener); // Listen to scroll events

    // getEventDetails();
    // Set up Firebase messaging listener
    _setupFirebaseMessaging();

  }

  void _setupFirebaseMessaging() {
    // Listen for foreground messages
    FirebaseMessaging.onMessage.listen(_handleFirebaseMessage);
  }
  

  void _handleFirebaseMessage(RemoteMessage message) {
    print("Received foreground message Ya Hassan .as,.: ${message.data}");
    

    // Check if this is a chat message
    if (message.data.containsKey('type') && message.data['type'] == 'chat') {
      // Extract conversation and message details
      String? conversationId = message.data['conversation_id'];
      String? messageId = message.data['message_id'];
      String? senderId = message.data['sender_id'];
      String? content = message.data['content'];
      int? timestamp = int.tryParse(message.data['timestamp'] ?? '');
      
  

    print("🛑🙄🔥👁️");
print(conversationId);
print(messageId);
print(senderId);
print(content);
print(timestamp);
        print("🛑🙄🔥👁️");
  
// && timestamp != null
      if (conversationId != null && messageId != null && senderId != null && content != null ) {
             
            //  _items.clear();
            //  _findItems();
            //  update();


     
        // Create a new message object
        // final newMessage = Message(
        //   id: messageId,
        //   senderId: senderId,
        //   content: content,
        //   timestamp: DateTime.fromMillisecondsSinceEpoch(timestamp),
        //   isRead: false,
        // );


        print("zl;xk ;zlk-----  $conversationId ----saklaksjd");
        
        // // Find if we already have this conversation in our list
        // int index = _items.indexWhere((conv) => conv.id == conversationId);
        

        int index = -1;
for (int i = 0; i < _items.length; i++) {

  var list = _items.toList();

  if (list[i].id == int.tryParse(conversationId)) {

    index = i;
    break;
  }
}
    

        print("✅");

        print(index);

        print("✅");

        if (index >= 0) {
          // Update existing conversation
          final existingConversation = _items[index];
          // print();
          
           print("✅⏲❤️");


          // existingConversation.copyWith(
          //   lastMessage: MessageModel(id: 09)
          // );

           final cov = existingConversation.copyWith(
            lastMessage: MessageModel(id: int.parse(messageId), text: content, createdAt: DateTime.now()),
            unreadCount: existingConversation.unreadCount! + 1,
          );
          


          // Create a new ConversationModel instance
final conversationModel = ConversationModel(
  id: cov.id,
  name: "Hassan Saeed",
  
  // Add other properties from cov
  lastMessage: cov.lastMessage,
  unreadCount: cov.unreadCount,
);
          // Remove the old conversation and insert the updated one at the beginning

          _items.removeAt(index);

          _items.insert(0, conversationModel);

          update();

        } else {
          // If it's a new conversation, fetch it from Firestore and add to the list
          // _fetchAndAddConversation(conversationId);
        }
      }
    }
  }

  void _changePaginationFilter(int page, int limit) {
    _paginationFilter.update((val) {
      val?.page = page;
      val?.limit = limit;
    });
  }

  // Scroll listener for pagination
  void _scrollListener() {
    var nextPageTrigger = 0.95 * scrollController.position.maxScrollExtent;
    if (scrollController.position.pixels >= nextPageTrigger &&
        !_isLoading.value &&
        _hasMore.value) {
      Future.delayed(Duration(seconds: 5)).then((value) => {
            _paginationFilter.update((val) {
              val?.page += 1;
            })
          });

      // _findItems();
    }
  }



  // Get List Of Marital Status
  Future<void> _findItems() async {
    
    print("🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑");

    if (Get.arguments != '') {

      final Map<String, dynamic> data = Get.arguments ?? {};

      final String finishedEvents = data['ed'] ?? '';
      
      final String myEvents = data['es'] ?? '';

      if (finishedEvents != '') {
        _paginationFilter.value.eventDuration = finishedEvents;
      }

      if (myEvents != '') {
        _paginationFilter.value.eventType = myEvents;
      }
    }
    

    // Call Marital Status Usecase.
    final failureOrMaritalStatus = await conversationsUsecase(_paginationFilter.value);

    failureOrMaritalStatus.fold((failure) {
      // Set Loading Attr False Initially.
      _isLoading.value = false;
    }, (receivedEventsData) {
      if (_isLoading.value && !_hasMore.value) return; // Avoid duplicate calls

      // Set Loading Attr True.
      _isLoading.value = true;

      if (receivedEventsData.isNotEmpty) {
        _items.addAll(receivedEventsData);
      } else {
        _hasMore.value = false; // No more data
      }

      // Add Result To Items Var.

      // Set Loading Attr False.
      
      _isLoading.value = false;
      update();
    });
  }





  Future<void> getEventDetails() async {
    print(Get.arguments);
    return Get.arguments;
    final failureOrEvent = await conversationsUsecase.getEventDetails(Get.arguments);

    failureOrEvent.fold((failure) {
      _isLoading.value = false;
    }, (receivedEvent) async {
      // receivedProduct.images!
      //     .add({"id": 0, "file": receivedProduct.image, "type": "image"});

      event = receivedEvent;

      print(receivedEvent);

      update();
    });
  }

  nextPage() {
    if (_hasMore.isFalse) return;
    _changePaginationFilter(page + 1, limit);
    update();
  }

  void onLoading() async {
    print(_paginationFilter.value);
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use loadFailed(),if no data return,use LoadNodata()
    nextPage();
    refreshController.loadComplete();
    update();
  }

  void onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // _items.clear();
    _findItems();
    refreshController.refreshCompleted();
  }

  @override
  void onClose() {
    scrollController.dispose();
    super.onClose();
  }
}
