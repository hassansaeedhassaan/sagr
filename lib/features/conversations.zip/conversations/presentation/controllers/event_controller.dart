import 'package:sagr/features/events/data/models/event_model.dart';
import 'package:sagr/features/events/domain/usecases/get_events.dart';
import 'package:get/get.dart';

class EventController extends GetxController {
  final EventsUsecase eventsUsecase;

  EventController(this.eventsUsecase);

  /// Rx Filters  Setter

  EventModel? eventModel;

  /// Products Loading
  /// @Setter
  final RxBool _isLoading = false.obs;

  /// List of products
  /// @ Getter
  bool get isLoading => _isLoading.value;

  EventModel? get event => eventModel;

  @override
  void onInit() {
    super.onInit();

    // Get Product Info And set main image.
    getEventInfo().then((value) {
      // _productImage.value = product!.image!;
    });
  }

  Future<void> getEventInfo() async {
    _isLoading.value = true;

    final failureOrProduct = await eventsUsecase.getEventDetails(Get.arguments);

    failureOrProduct.fold((failure) {
      _isLoading.value = false;
    }, (receivedProduct) async {
      // receivedProduct.images!
      //     .add({"id": 0, "file": receivedProduct.image, "type": "image"});

      eventModel = receivedProduct;

      // generateVideoThumb(receivedProduct);

      _isLoading.value = false;

      update();
    });
  }
}
