import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sagr/features/conversations/data/models/conversation_model.dart';
import 'package:sagr/features/conversations/data/models/message_model.dart';
import 'package:get/get.dart';
import 'package:sagr/models/user_model.dart';

import '../../../../models/pagination_filter.dart';
import '../../domain/usecases/get_conversations.dart';

class ConversationChatController extends GetxController {
  final ConversationsUsecase conversationUsecase;

  ConversationChatController(this.conversationUsecase);

  final ScrollController scrollController = ScrollController();

  void scrollToBottom() {
    scrollController.animateTo(
      scrollController.position.maxScrollExtent - 100,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOut,
    );
  }

  void scrollToTop() {
    scrollController.animateTo(
      0.0,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOut,
    );
  }

  /// Rx Filters  Setter

  ConversationModel? conversation;

  /// Products Loading
  /// @Setter
  final RxBool _isLoading = false.obs;

  /// List of products
  /// @ Getter
  bool get isLoading => _isLoading.value;

  ConversationModel? get event => conversation;

  /// Rx Filters  Setter
  final _paginationFilter = PaginationFilter().obs;
  final RxBool _lastPage = false.obs;
  final RxBool _hasMore = true.obs;

  /// Rx Filters  Getter
  int get limit => _paginationFilter.value.limit;
  int get page => _paginationFilter.value.page;
  bool get lastPage => _lastPage.value;
  bool get hasMore => _hasMore.value;

  @override
  void onInit() {
    super.onInit();
    _changePaginationFilter(1, 5);

    // Get Product Info And set main image.
    getChatMessages().then((value) {
      // _productImage.value = product!.image!;
      _scrollToBottom();
      update();
    });

    _setupFirebaseMessaging();
    ever(_items, (_) {
      _scrollToBottom();
    });
  }

  void _setupFirebaseMessaging() {
    // Listen for foreground messages
    FirebaseMessaging.onMessage.listen(_handleFirebaseMessage);
  }

  void _handleFirebaseMessage(RemoteMessage message) {
    print("🛑🙄🔥👁️");
    print(message.data);

    _items.add(MessageModel(
        id: int.parse(message.data['message_id']),
        text: "${message.data['message']}",
        userId: int.parse(message.data['sender_id']),
        conversationId: int.parse(message.data['conversation_id']),
        createdAt: DateTime.now()));


    // _scrollToBottom();
    // _scrollToBottom();
    update();
    print("🛑🙄🔥👁️");
    // Check if this is a chat message
    if (message.data.containsKey('type') && message.data['type'] == 'chat') {
      // Extract conversation and message details
      String? conversationId = message.data['conversation_id'];
      String? messageId = message.data['message_id'];
      String? senderId = message.data['sender_id'];
      String? content = message.data['content'];
      int? timestamp = int.tryParse(message.data['timestamp'] ?? '');

      print("🛑🙄🔥👁️");
      print(conversationId);
      print(messageId);
      print(senderId);
      print(content);
      print(timestamp);
      print("🛑🙄🔥👁️");

// && timestamp != null
      if (conversationId != null &&
          messageId != null &&
          senderId != null &&
          content != null) {
        //  _items.clear();
        //  _findItems();
        //  update();

        // Create a new message object
        // final newMessage = Message(
        //   id: messageId,
        //   senderId: senderId,
        //   content: content,
        //   timestamp: DateTime.fromMillisecondsSinceEpoch(timestamp),
        //   isRead: false,
        // );

        print("zl;xk ;zlk-----  $conversationId ----saklaksjd");

        // // Find if we already have this conversation in our list
        // int index = _items.indexWhere((conv) => conv.id == conversationId);

        int index = -1;
        for (int i = 0; i < _items.length; i++) {
          var list = _items.toList();

          if (list[i].id == int.tryParse(conversationId)) {
            index = i;
            break;
          }
        }

        print("✅");

        print(index);

        print("✅");

        if (index >= 0) {
          // Update existing conversation
          final existingConversation = _items[index];
          // print();

          print("✅⏲❤️");

          // existingConversation.copyWith(
          //   lastMessage: MessageModel(id: 09)
          // );

          // final cov = existingConversation.copyWith(
          //   lastMessage: MessageModel(
          //       id: int.parse(messageId),
          //       text: content,
          //       createdAt: DateTime.now()),
          //   unreadCount: existingConversation.unreadCount! + 1,
          // );

          // Create a new ConversationModel instance
          // final conversationModel = ConversationModel(
          //   id: cov.id,
          //   name: "Hassan Saeed",

          //   // Add other properties from cov
          //   lastMessage: cov.lastMessage,
          //   unreadCount: cov.unreadCount,
          // );
          // Remove the old conversation and insert the updated one at the beginning

          // _items.removeAt(index);

          // _items.insert(0, conversationModel);

          // update();
        } else {
          // If it's a new conversation, fetch it from Firestore and add to the list
          // _fetchAndAddConversation(conversationId);
        }
      }

      update();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController.hasClients) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 100),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _changePaginationFilter(int page, int limit) {
    _paginationFilter.update((val) {
      val?.page = page;
      val?.limit = limit;
    });
  }

  final _items = <MessageModel>[].obs;

  List<MessageModel> get messages => _items.toList();

  Future<void> getChatMessages() async {
    _isLoading.value = true;

    final failureOrProduct = await conversationUsecase.getMessages(
        Get.arguments, _paginationFilter.value);

    failureOrProduct.fold((failure) {
      _isLoading.value = false;
    }, (receivedMessages) async {
      // receivedProduct.images!
      //     .add({"id": 0, "file": receivedProduct.image, "type": "image"});

      _isLoading.value = true;

      if (receivedMessages.isNotEmpty) {
        _items.addAll(receivedMessages);

// for (int i = 0; i < receivedMessages.length; i++) {

//        _items.add(MessageModel.fromJson(receivedMessages.elementAt(index)));
//         // _items.add(MessageModel.fromJson({
//         //   'id': receivedProduct[i].id,
//         //   'message': receivedProduct[i].message,
//         //   'createdAt': receivedProduct[i].createdAt!.toIso8601String(),
//         //   'sentBy': receivedProduct[i].user!.id,
//         // // 'reply_message': replyMessage.toJson(),
//         // // 'reaction': reaction.toJson(),
//         //   'message_type': 'text',
//         //   'voice_message_duration': '0',
//         //   'status': 'pending',
//         //   'user':receivedProduct[i].user!
//         // }));

// }
      } else {
        _hasMore.value = false; // No more data
      }

      // print(receivedProduct);
      // conversation = receivedProduct;

      // generateVideoThumb(receivedProduct);

      _isLoading.value = false;

      update();
    });
  }

  Future<void> sendVoiceMessage(context, message) async {
    final currentUserId = GetStorage().read('userData')['id'];


print('message1111');

print(message);

print('message1111');

    _items.add(MessageModel(
        id: 0,
        type: 'voice',
        text: '',
        voiceFile: File(message),
        userId: currentUserId,
        conversationId: Get.arguments,
        createdAt: DateTime.now()));

    final Map<String, dynamic> body = {
      'user_id': currentUserId,
      'conversation_id': Get.arguments,
      'text': "voiceMessage",
      'voice_file': message,
      'type': 'voice',
      'voiceFile': message
    };

    if (kDebugMode) {
      print("UUUU 🔥🔥🔥🔥 ");
      print(body);

    }

    final failureOrSentMessage = await conversationUsecase.sendMessage(body);

    scrollToBottom();
  }

  Future<void> sendTextMessage(context, message) async {


    final currentUserId = GetStorage().read('userData')['id'];





    _items.add(MessageModel(
        id: 0,
        text: message,
        userId: currentUserId,
        conversationId: Get.arguments,
        createdAt: DateTime.now()));

    final Map<String, dynamic> body = {
      'user_id': currentUserId,
      'conversation_id': Get.arguments,
      'text': message,
      'type': 'text'
    };


    if (kDebugMode) {
      print("Ayooya 2222🔥🔥🔥🔥 ");
      print(message);
      print( Get.arguments);
      print( body );
      print("Ayooya 2222🔥🔥🔥🔥 ");
    }

update();

    final failureOrSentMessage = await conversationUsecase.sendMessage(body);

    // scrollToBottom();
    // return Future.delayed(Duration(microseconds: 10));
  }

  @override
  void onClose() {
    scrollController.dispose();
    super.onClose();
  }
}
