import 'package:get/get.dart';
import 'package:sagr/features/conversations/presentation/controllers/chat_controller.dart';

import '../../data/datasource/conversations_data_source.dart';
import '../../data/repositories/event_repository_impl.dart';
import '../../domain/usecases/get_conversations.dart';
import '../controllers/conversations_controller.dart';

class ConversationsBindings implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ConversationsController(Get.find()));
    Get.lazyPut(() => ConversationChatController(Get.find()));

    Get.lazyPut(() => ConversationsDataSourceImpl(dio: Get.find()));
    Get.lazyPut(
        () => ConversationsRepositoryImpl(Get.find<ConversationsDataSourceImpl>()));
    Get.put(ConversationsUsecase(Get.find<ConversationsRepositoryImpl>()),
        permanent: true);
  }
}
