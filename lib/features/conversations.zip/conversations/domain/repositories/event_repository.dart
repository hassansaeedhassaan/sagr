import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:sagr/features/conversations/data/models/message_model.dart';
import 'package:sagr/models/pagination_filter.dart';

import '../../../../core/error/failures.dart';
import '../../data/models/conversation_model.dart';
import '../../data/models/event_model.dart';

abstract class ConversationRepository {

  Future<Either<Failure, List<ConversationModel>>> getConversations(PaginationFilter filter);
  
  Future<Either<Failure, EventModel>> getEventDetails(int id);

  Future<Either<Failure,  List<MessageModel>>> getMessages(int conversationId, PaginationFilter filter);

  Future<Either<Failure, Response>> apply(Map<String, dynamic> body);

    Future<Either<Failure, Response>> sendMessage(Map<String, dynamic> body);

}
