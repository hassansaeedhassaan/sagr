import 'package:equatable/equatable.dart';
import 'package:sagr/models/user_model.dart';

import '../../data/models/message_model.dart';


enum ConversationType { private, group }
class Conversation extends Equatable {
  

  final int id;
  final String? name;
  final String? type;
  final String? photo;
  final int? createdBy;
  final List<UserModel>? users;
  // final Message? lastMessage;
  final int? unreadCount;
  final String? createdAt;
  final String? updatedAt;
  final MessageModel? lastMessage;


  const Conversation({required this.id,this.name, this.type, this.photo,this.createdBy, this.users, this.unreadCount = 0, this.createdAt, this.updatedAt, this.lastMessage});

  @override

  List<Object?> get props => [id,name,type, photo,createdBy,users, unreadCount, createdAt, updatedAt, lastMessage];

  // Optional: Add copyWith for immutability and easy updates
  Conversation copyWith({
    int? id,
    String? name,
    String? type,
    String? description,
    String? photo,
    int? createdBy,
    int? unreadCount,
    String? createdAt,
    String? updatedAt,
    MessageModel? lastMessage

  }) {
    return Conversation(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      photo: photo??this.photo,
      createdBy: createdBy??this.createdBy,
      unreadCount: unreadCount??this.unreadCount,
      createdAt: createdAt??this.createdAt,
      updatedAt: updatedAt??this.updatedAt,
      lastMessage: lastMessage??this.lastMessage
    
    );
  }

  // Optional: Add factory constructor for JSON parsing
  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      id: json['id'],
      name: json['name'],
      type: json['type'],
      photo: json['photo'],
      createdBy: json['createdBy'],
      unreadCount: json['unreadCount'],
      createdAt: json['createdAt'],
      updatedAt: json['updatedAt'],
      lastMessage: json['lastMessage']
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'photo': photo,
      'createdBy': createdBy,
      'unreadCount': unreadCount,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'lastMessage': lastMessage
    };
  }
}