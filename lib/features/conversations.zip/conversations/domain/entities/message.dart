import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:sagr/models/user_model.dart';


class Message extends Equatable {
  

  final int id;
    final String? text;

    final int? userId;
  final int? conversationId;
  // final String? content;
  // final String? type;
  // final UserModel? user;
  // final String? message;
  // final bool? unread;
  final DateTime? createdAt;
  final File? voiceFile;
  final String? voicePath;
  // final String? sentBy;



  const Message( {required this.id,this.text, this.userId,this.conversationId, this.createdAt, this.voicePath, this.voiceFile});

  @override
  
  List<Object?> get props => [id,text,userId,conversationId, createdAt, voicePath, voiceFile];

  // Optional: Add copyWith for immutability and easy updates
  Message copyWith({
    int? id,
    String? text,
    int? userId,
    int? conversationId,
    String? voicePath,
    File?voiceFile,
    // String? content,
    // String? type,
    // UserModel? user,
    // String? message,
    // String? sentBy,
    // bool? unread,
    DateTime? createdAt,
    
  }) {
    return Message(
      id: id ?? this.id,
      text: text??this.text,
      userId: userId??this.userId,
      conversationId: conversationId??this.conversationId,
      voicePath: voicePath??this.voicePath,
      voiceFile: voiceFile??this.voiceFile,
            
      // content: content ?? this.content,
      // type: type ?? this.type,
      // user: user??this.user,
      // message: message?? this.message,
      createdAt: createdAt??this.createdAt,
      // unread: unread??this.unread,
      // sentBy: sentBy??this.sentBy,

    
    );
  }

  // Optional: Add factory constructor for JSON parsing
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'],
      text: json['text']??"",
      userId: json['userId']??"",
      conversationId: json['userId']??"",
      voicePath: json['voice_file']??"",
      voiceFile: json['voice_file']??"",

      // content: json['content'],
      // type: json['type'],
      // user: UserModel.fromJson(json['user']),
      // message: json['content'] ?? "Message Error!",
      createdAt: json['created_at'],
      // unread: true,
      // text: json['text']??"",
      // sentBy: json['user_id'].toString()
    );
  }



  Map<String, dynamic> toJson() {
    return {
      'id': id,
      // 'content': content,
      // 'type': type,
      // 'user': user,
      // 'message': message,
      'voicePath': voicePath,
      'text': text,
      'userId': userId,
      'conversationId':  conversationId,
      'createdAt': createdAt
    };
  }

}