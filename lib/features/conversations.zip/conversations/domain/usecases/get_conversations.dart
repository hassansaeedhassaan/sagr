import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:sagr/features/conversations/data/models/message_model.dart';
import 'package:sagr/models/pagination_filter.dart';
import '../../../../core/error/failures.dart';
import '../../data/models/conversation_model.dart';
import '../../data/models/event_model.dart';
import '../repositories/event_repository.dart';

class ConversationsUsecase {
  
  ConversationRepository conversationRepository;
  
  ConversationsUsecase(this.conversationRepository);

  Future<Either<Failure, List<ConversationModel>>> call(PaginationFilter filter) async {
    return await conversationRepository.getConversations(filter);
  }


 Future<Either<Failure, EventModel>> getEventDetails(int id) async {
    return await conversationRepository.getEventDetails(id);
  }

   Future<Either<Failure, List<MessageModel>>> getMessages(int conversationId, PaginationFilter filter) async {
    return await conversationRepository.getMessages(conversationId, filter);
  }



 Future<Either<Failure, Response>> apply(
      Map<String, dynamic> body) async {
    return await conversationRepository.apply(body);
  }



 Future<Either<Failure, Response>> sendMessage(
      Map<String, dynamic> body) async {
    return await conversationRepository.sendMessage(body);
  }

  
}
