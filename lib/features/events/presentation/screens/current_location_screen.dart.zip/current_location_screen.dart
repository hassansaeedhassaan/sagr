import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:math' as math;

import '../services/location_check_result.dart';

// Zone point model
class ZonePoint {
  final String id;
  final String zoneId;
  final double latitude;
  final double longitude;
  final int order;

  ZonePoint({
    required this.id,
    required this.zoneId,
    required this.latitude,
    required this.longitude,
    required this.order,
  });

  factory ZonePoint.fromJson(Map<String, dynamic> json) {
    return ZonePoint(
      id: json['id'].toString(),
      zoneId: json['zone_id'].toString(),
      latitude: double.parse(json['latitude'].toString()),
      longitude: double.parse(json['longitude'].toString()),
      order: int.parse(json['order'].toString()),
    );
  }
}


class ZoneLocationService {
  // Your zone coordinates
  static List<Map<String, dynamic>> get zoneData => [
    {"id":"1","zone_id":"2","latitude":"30.99837673","longitude":"31.36143810","order":"0"},
    {"id":"2","zone_id":"2","latitude":"30.99827556","longitude":"31.36119134","order":"1"},
    {"id":"3","zone_id":"2","latitude":"30.99807324","longitude":"31.36151320","order":"2"},
    {"id":"4","zone_id":"2","latitude":"30.99753064","longitude":"31.36053688","order":"3"},
    {"id":"5","zone_id":"2","latitude":"30.99764100","longitude":"31.36039740","order":"4"},
    {"id":"6","zone_id":"2","latitude":"30.99817440","longitude":"31.36112696","order":"5"},
    {"id":"7","zone_id":"2","latitude":"30.99840432","longitude":"31.36083728","order":"6"},
    {"id":"8","zone_id":"2","latitude":"30.99846869","longitude":"31.36078364","order":"7"},
    {"id":"9","zone_id":"2","latitude":"30.99874459","longitude":"31.36137373","order":"8"},
    {"id":"10","zone_id":"2","latitude":"30.99879977","longitude":"31.36148101","order":"9"},
    {"id":"11","zone_id":"2","latitude":"30.99856985","longitude":"31.36172778","order":"10"},
  ];

  // Convert data to ZonePoint objects and sort by order
  static List<ZonePoint> get zonePoints {
    return zoneData
        .map((data) => ZonePoint.fromJson(data))
        .toList()
      ..sort((a, b) => a.order.compareTo(b.order));
  }

  // Check if current location is inside the zone
  static Future<LocationCheckResult?> checkCurrentLocationInZone() async {
    try {
      // Get current location
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        throw Exception('Location services are disabled');
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Location permissions denied');
        }
      }

      Position currentPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      List<ZonePoint> points = zonePoints;
      
      // Check if inside polygon
      bool isInside = _isPointInPolygon(
        currentPosition.latitude,
        currentPosition.longitude,
        points,
      );

      // Calculate distance to zone
      double distance = isInside ? 0.0 : _calculateDistanceToPolygon(
        currentPosition.latitude,
        currentPosition.longitude,
        points,
      );

      return LocationCheckResult(
        isInside: isInside,
        distanceToZone: distance,
        currentPosition: currentPosition,
        zonePoints: points,
      );

    } catch (e) {
      print('Error checking location: $e');
      return null;
    }
  }

  // Point-in-polygon algorithm (Ray casting)
  static bool _isPointInPolygon(double lat, double lng, List<ZonePoint> polygon) {
    int intersections = 0;
    
    for (int i = 0; i < polygon.length; i++) {
      int j = (i + 1) % polygon.length;
      
      if (_rayIntersectsSegment(
        lat, lng,
        polygon[i].latitude, polygon[i].longitude,
        polygon[j].latitude, polygon[j].longitude,
      )) {
        intersections++;
      }
    }
    
    return intersections % 2 == 1;
  }

  // Ray casting helper
  static bool _rayIntersectsSegment(
    double px, double py,
    double ax, double ay,
    double bx, double by,
  ) {
    if (ay > py == by > py) return false;
    
    double intersectionX = (bx - ax) * (py - ay) / (by - ay) + ax;
    return px < intersectionX;
  }

  // Calculate distance to polygon (minimum distance to any edge)
  static double _calculateDistanceToPolygon(
    double lat, double lng, List<ZonePoint> polygon,
  ) {
    double minDistance = double.infinity;

    for (int i = 0; i < polygon.length; i++) {
      int j = (i + 1) % polygon.length;
      
      double distance = _distanceToLineSegment(
        lat, lng,
        polygon[i].latitude, polygon[i].longitude,
        polygon[j].latitude, polygon[j].longitude,
      );
      
      if (distance < minDistance) {
        minDistance = distance;
      }
    }

    return minDistance;
  }

  // Distance from point to line segment
  static double _distanceToLineSegment(
    double px, double py,
    double ax, double ay,
    double bx, double by,
  ) {
    double A = px - ax;
    double B = py - ay;
    double C = bx - ax;
    double D = by - ay;

    double dot = A * C + B * D;
    double lenSq = C * C + D * D;
    
    if (lenSq == 0) {
      // Line segment is actually a point
      return Geolocator.distanceBetween(px, py, ax, ay);
    }

    double param = dot / lenSq;

    double xx, yy;

    if (param < 0) {
      xx = ax;
      yy = ay;
    } else if (param > 1) {
      xx = bx;
      yy = by;
    } else {
      xx = ax + param * C;
      yy = ay + param * D;
    }

    return Geolocator.distanceBetween(px, py, xx, yy);
  }

  // Get zone center point
  static Map<String, double> getZoneCenter() {
    List<ZonePoint> points = zonePoints;
    
    double avgLat = points.map((p) => p.latitude).reduce((a, b) => a + b) / points.length;
    double avgLng = points.map((p) => p.longitude).reduce((a, b) => a + b) / points.length;
    
    return {'latitude': avgLat, 'longitude': avgLng};
  }
}

// Example usage screen
class ZoneLocationChecker extends StatefulWidget {
  @override
  State<ZoneLocationChecker> createState() => _ZoneLocationCheckerState();
}

class _ZoneLocationCheckerState extends State<ZoneLocationChecker> {
  LocationCheckResult? _result;
  bool _isLoading = false;
  String _status = 'Tap to check location';

  Future<void> _checkLocation() async {
    setState(() {
      _isLoading = true;
      _status = 'Checking location...';
    });

    try {
      LocationCheckResult? result = await ZoneLocationService.checkCurrentLocationInZone();
      
      if (result != null) {
        setState(() {
          _result = result;
          _status = result.isInside 
              ? 'You are INSIDE the zone!' 
              : 'You are OUTSIDE the zone';
        });
      } else {
        setState(() {
          _status = 'Failed to get location';
        });
      }
    } catch (e) {
      setState(() {
        _status = 'Error: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _checkLocation(); // Auto-check on load
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Zone Location Checker'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Status card
            Card(
              color: _result?.isInside == true ? Colors.green.shade50 : Colors.red.shade50,
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Icon(
                      _result?.isInside == true ? Icons.check_circle : Icons.location_off,
                      size: 60,
                      color: _result?.isInside == true ? Colors.green : Colors.red,
                    ),
                    SizedBox(height: 10),
                    Text(
                      _status,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 20),

            // Location details
            if (_result != null) ...[
              Card(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Location Details',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      Text('Current Latitude: ${_result!.currentPosition.latitude.toStringAsFixed(8)}'),
                      Text('Current Longitude: ${_result!.currentPosition.longitude.toStringAsFixed(8)}'),
                      Text('Accuracy: ${_result!.currentPosition.accuracy.toStringAsFixed(2)} meters'),
                      SizedBox(height: 10),
                      Text(
                        _result!.isInside 
                            ? 'Status: Inside Zone'
                            : 'Distance to Zone: ${_result!.distanceToZone.toStringAsFixed(2)} meters',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: _result!.isInside ? Colors.green : Colors.orange,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              SizedBox(height: 20),

              // Zone info
              Card(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Zone Information',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      Text('Zone ID: ${_result!.zonePoints.first.zoneId}'),
                      Text('Total Points: ${_result!.zonePoints.length}'),
                      
                      // Zone center
                      Builder(
                        builder: (context) {
                          Map<String, double> center = ZoneLocationService.getZoneCenter();
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Zone Center:'),
                              Text('  Lat: ${center['latitude']!.toStringAsFixed(8)}'),
                              Text('  Lng: ${center['longitude']!.toStringAsFixed(8)}'),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],

            Spacer(),

            // Refresh button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _checkLocation,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isLoading
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                          SizedBox(width: 10),
                          Text('Checking...'),
                        ],
                      )
                    : Text('Check Location Again'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Simplified usage function
class QuickZoneChecker {
  static Future<Map<String, dynamic>?> checkCurrentLocation() async {
    try {
      LocationCheckResult? result = await ZoneLocationService.checkCurrentLocationInZone();
      
      if (result != null) {
        return {
          'isInside': result.isInside,
          'distance': result.distanceToZone,
          'latitude': result.currentPosition.latitude,
          'longitude': result.currentPosition.longitude,
          'accuracy': result.currentPosition.accuracy,
        };
      }
    } catch (e) {
      print('Error: $e');
    }
    return null;
  }

  // Quick boolean check
  static Future<bool> isCurrentLocationInZone() async {
    LocationCheckResult? result = await ZoneLocationService.checkCurrentLocationInZone();
    return result?.isInside ?? false;
  }

  // Quick distance check
  static Future<double?> getDistanceToZone() async {
    LocationCheckResult? result = await ZoneLocationService.checkCurrentLocationInZone();
    return result?.distanceToZone;
  }
}

// Real-time monitoring
class RealTimeZoneMonitor extends StatefulWidget {
  final Function(bool isInside, double distance)? onLocationChange;

  const RealTimeZoneMonitor({Key? key, this.onLocationChange}) : super(key: key);

  @override
  State<RealTimeZoneMonitor> createState() => _RealTimeZoneMonitorState();
}

class _RealTimeZoneMonitorState extends State<RealTimeZoneMonitor> {
  bool? _isInside;
  double? _distance;
  late Stream<Position> _locationStream;

  @override
  void initState() {
    super.initState();
    _startLocationMonitoring();
  }

  void _startLocationMonitoring() {
    _locationStream = Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5, // Update every 5 meters
      ),
    );

    _locationStream.listen((Position position) {
      _checkLocationInZone(position);
    });
  }

  void _checkLocationInZone(Position position) {
    List<ZonePoint> points = ZoneLocationService.zonePoints;
    
    bool isInside = ZoneLocationService._isPointInPolygon(
      position.latitude,
      position.longitude,
      points,
    );

    double distance = isInside ? 0.0 : ZoneLocationService._calculateDistanceToPolygon(
      position.latitude,
      position.longitude,
      points,
    );

    setState(() {
      _isInside = isInside;
      _distance = distance;
    });

    // Callback for parent widget
    if (widget.onLocationChange != null) {
      widget.onLocationChange!(isInside, distance);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Text('Real-time Zone Monitoring'),
          SizedBox(height: 10),
          if (_isInside != null) ...[
            Text(
              _isInside! ? 'INSIDE ZONE' : 'OUTSIDE ZONE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: _isInside! ? Colors.green : Colors.red,
              ),
            ),
            if (_distance != null && !_isInside!)
              Text('Distance: ${_distance!.toStringAsFixed(1)}m'),
          ] else
            CircularProgressIndicator(),
        ],
      ),
    );
  }
}